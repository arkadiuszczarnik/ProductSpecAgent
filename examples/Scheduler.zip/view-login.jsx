// VIEW 5 — LOGIN SCREEN
// Two variants on one artboard: split-hero (left) and centered-card (right).
// Real form: email + password validation, show/hide password, remember-me, SSO.

const LoginView = () => {
  return (
    <div style={{ height: "100%", background: "var(--bg-0)" }}>
      <LoginSplit />
    </div>
  );
};

// ─── Variant 1: split with marketing/branding panel on the left ───
const LoginSplit = () => {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", height: "100%" }}>
      <aside style={lvStyles.heroPanel}>
        <div style={lvStyles.heroBrand}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: "linear-gradient(135deg, var(--accent), oklch(0.62 0.12 210))",
            display: "grid", placeItems: "center",
            color: "oklch(0.18 0.008 240)", fontWeight: 700, fontSize: 16,
          }}>S</div>
          <div style={{ fontWeight: 600, fontSize: 15 }}>Scheduler</div>
        </div>

        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", maxWidth: 360 }}>
          <div style={{ fontSize: 11, color: "var(--accent)", textTransform: "uppercase", letterSpacing: 1.5, fontWeight: 600, marginBottom: 14 }}>Ingest Operations</div>
          <h1 style={{ fontSize: 30, lineHeight: 1.15, fontWeight: 600, margin: 0, color: "var(--fg-0)", letterSpacing: -0.4, textWrap: "pretty" }}>
            Alle Feeds planen, routen und aufzeichnen — an einem Ort.
          </h1>
          <p style={{ fontSize: 14, color: "var(--fg-2)", marginTop: 16, lineHeight: 1.6 }}>
            Pool-Kapazitäten, Quellen-Routing und AVID-Workflows über den gesamten Sendetag verwalten.
          </p>

          {/* Mini status preview */}
          <div style={lvStyles.heroPreview}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <span style={{ width: 6, height: 6, borderRadius: 999, background: "oklch(0.74 0.12 25)", boxShadow: "0 0 0 3px oklch(0.74 0.12 25 / 0.25)" }} />
              <span className="mono" style={{ fontSize: 11, color: "var(--fg-1)" }}>Mo 30.04.26 · 13:24</span>
              <span style={{ flex: 1 }} />
              <span style={{ fontSize: 10.5, color: "var(--fg-3)" }}>4 aktive Aufnahmen</span>
            </div>
            <PreviewBar label="Bundesliga · 1. Halbzeit" status="recording" w="68%" />
            <PreviewBar label="Tagesschau · DPA-Feed"    status="running"   w="92%" />
            <PreviewBar label="Champions · Studio-Auftakt" status="planned"  w="55%" />
          </div>
        </div>

        <div style={{ fontSize: 11, color: "var(--fg-3)" }}>
          © 2026 RTL · Ingest Operations Plattform
        </div>
      </aside>

      <main style={lvStyles.formPanel}>
        <div style={{ width: "100%", maxWidth: 340 }}>
          <LoginForm />
        </div>
      </main>
    </div>
  );
};

const PreviewBar = ({ label, status, w }) => {
  const colors = {
    recording: { bg: "oklch(0.74 0.12 25 / 0.32)", border: "oklch(0.74 0.12 25)" },
    running:   { bg: "oklch(0.74 0.12 210 / 0.30)", border: "var(--accent)" },
    planned:   { bg: "oklch(0.26 0.010 240)", border: "oklch(0.36 0.012 240)" },
  }[status];
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
      <span style={{ fontSize: 10.5, color: "var(--fg-3)", width: 60, flex: "0 0 60px" }}>Pool {Math.ceil(Math.random() * 4)}</span>
      <div style={{ flex: 1, height: 18, background: "var(--bg-2)", borderRadius: 3, position: "relative", overflow: "hidden" }}>
        <div style={{
          position: "absolute", left: 0, top: 0, bottom: 0,
          width: w,
          background: colors.bg,
          borderLeft: `2px solid ${colors.border}`,
          borderRadius: 3,
          padding: "0 6px",
          display: "flex", alignItems: "center",
          fontSize: 10, color: "var(--fg-0)",
          overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis",
        }}>
          {label}
        </div>
      </div>
    </div>
  );
};

// ─── Variant 2: centered card on plate ───
const LoginCentered = () => {
  return (
    <div style={{
      height: "100%",
      display: "grid", placeItems: "center",
      background: "radial-gradient(ellipse at 50% 30%, oklch(0.74 0.12 210 / 0.10), transparent 60%), var(--bg-0)",
      padding: 32,
    }}>
      <div style={lvStyles.card}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, justifyContent: "center", marginBottom: 28 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 9,
            background: "linear-gradient(135deg, var(--accent), oklch(0.62 0.12 210))",
            display: "grid", placeItems: "center",
            color: "oklch(0.18 0.008 240)", fontWeight: 700, fontSize: 18,
          }}>S</div>
          <div>
            <div style={{ fontWeight: 600, fontSize: 16 }}>Scheduler</div>
            <div style={{ fontSize: 11, color: "var(--fg-3)" }}>Ingest Ops · v4.2</div>
          </div>
        </div>
        <LoginForm centered />
      </div>
    </div>
  );
};

// ─── Shared form component ───
const LoginForm = ({ centered }) => {
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [show, setShow] = React.useState(false);
  const [remember, setRemember] = React.useState(true);
  const [touched, setTouched] = React.useState({ email: false, password: false });
  const [submitted, setSubmitted] = React.useState(false);

  const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const pwOk = password.length >= 8;

  const emailErr = (touched.email || submitted) && email && !emailOk ? "Bitte eine gültige E-Mail-Adresse eingeben." : null;
  const emailEmpty = (touched.email || submitted) && !email ? "E-Mail ist erforderlich." : null;
  const pwErr = (touched.password || submitted) && password && !pwOk ? "Mindestens 8 Zeichen." : null;
  const pwEmpty = (touched.password || submitted) && !password ? "Passwort ist erforderlich." : null;

  const onSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div style={{ width: "100%" }}>
      <div style={{ textAlign: centered ? "center" : "left", marginBottom: 22 }}>
        <h2 style={{ fontSize: 20, fontWeight: 600, margin: 0, letterSpacing: -0.2 }}>Willkommen zurück</h2>
        <p style={{ fontSize: 13, color: "var(--fg-2)", marginTop: 6, marginBottom: 0 }}>
          Melde dich an, um zu deinem Scheduler-Arbeitsbereich zu gelangen.
        </p>
      </div>

      <form onSubmit={onSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div>
          <label style={lvStyles.label}>E-Mail</label>
          <input
            className="input"
            type="email"
            value={email}
            placeholder="name@rtl.de"
            onChange={(e) => setEmail(e.target.value)}
            onBlur={() => setTouched(t => ({ ...t, email: true }))}
            style={{
              ...((emailErr || emailEmpty) ? { borderColor: "oklch(0.78 0.12 25)" } : null),
            }}
            autoComplete="email"
          />
          {(emailErr || emailEmpty) && (
            <div style={lvStyles.errorMsg}>⚠ {emailErr || emailEmpty}</div>
          )}
        </div>

        <div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <label style={lvStyles.label}>Passwort</label>
            <a href="#" style={lvStyles.link}>Vergessen?</a>
          </div>
          <div style={{ position: "relative" }}>
            <input
              className="input"
              type={show ? "text" : "password"}
              value={password}
              placeholder="••••••••"
              onChange={(e) => setPassword(e.target.value)}
              onBlur={() => setTouched(t => ({ ...t, password: true }))}
              style={{
                paddingRight: 44,
                ...((pwErr || pwEmpty) ? { borderColor: "oklch(0.78 0.12 25)" } : null),
              }}
              autoComplete="current-password"
            />
            <button
              type="button"
              onClick={() => setShow(s => !s)}
              style={lvStyles.showBtn}
              tabIndex={-1}
            >
              {show ? "Verbergen" : "Anzeigen"}
            </button>
          </div>
          {(pwErr || pwEmpty) && (
            <div style={lvStyles.errorMsg}>⚠ {pwErr || pwEmpty}</div>
          )}
        </div>

        <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5, color: "var(--fg-1)", cursor: "pointer", userSelect: "none" }}>
          <input
            type="checkbox"
            checked={remember}
            onChange={(e) => setRemember(e.target.checked)}
            style={{ accentColor: "var(--accent)", width: 14, height: 14 }}
          />
          Auf diesem Gerät angemeldet bleiben
        </label>

        <button
          type="submit"
          className="btn primary"
          style={{ justifyContent: "center", padding: "9px 14px", fontSize: 13, fontWeight: 500, marginTop: 4 }}
        >
          Anmelden
        </button>

        {submitted && emailOk && pwOk && (
          <div style={{
            background: "oklch(0.62 0.10 145 / 0.18)",
            border: "1px solid oklch(0.62 0.10 145)",
            color: "oklch(0.85 0.06 145)",
            borderRadius: 6,
            padding: "8px 10px",
            fontSize: 12,
            display: "flex", alignItems: "center", gap: 8,
          }}>
            ✓ Authentifiziert · Weiterleitung zur Timeline…
          </div>
        )}

        <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "4px 0", color: "var(--fg-3)", fontSize: 11 }}>
          <div style={{ flex: 1, height: 1, background: "var(--border-0)" }} />
          <span>oder fortfahren mit</span>
          <div style={{ flex: 1, height: 1, background: "var(--border-0)" }} />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          <button type="button" className="btn" style={{ justifyContent: "center", fontSize: 12 }}>
            <span style={{ fontWeight: 700, color: "var(--fg-0)" }}>SSO</span>
            <span style={{ color: "var(--fg-2)" }}>· RTL</span>
          </button>
          <button type="button" className="btn" style={{ justifyContent: "center", fontSize: 12 }}>
            <span style={{ color: "var(--fg-2)" }}>⌬</span> Microsoft
          </button>
        </div>
      </form>

      <p style={{ marginTop: 22, fontSize: 12, color: "var(--fg-3)", textAlign: centered ? "center" : "left" }}>
        Noch keinen Zugang? <a href="#" style={lvStyles.link}>Account anfragen</a>
      </p>
    </div>
  );
};

const lvStyles = {
  heroPanel: {
    background: "linear-gradient(180deg, var(--bg-1), var(--bg-0))",
    borderRight: "1px solid var(--border-0)",
    padding: "32px 36px",
    display: "flex", flexDirection: "column", gap: 30,
    position: "relative",
    overflow: "hidden",
  },
  heroBrand: { display: "flex", alignItems: "center", gap: 10 },
  heroPreview: {
    marginTop: 28,
    padding: 14,
    background: "var(--bg-1)",
    border: "1px solid var(--border-0)",
    borderRadius: 8,
  },
  formPanel: {
    display: "grid", placeItems: "center",
    padding: 32,
  },
  card: {
    width: "100%", maxWidth: 380,
    background: "var(--bg-1)",
    border: "1px solid var(--border-0)",
    borderRadius: 12,
    padding: 32,
    boxShadow: "0 20px 60px oklch(0 0 0 / 0.4)",
  },
  label: {
    display: "block",
    fontSize: 11, color: "var(--fg-2)",
    textTransform: "uppercase", letterSpacing: 0.4, fontWeight: 500,
    marginBottom: 6,
  },
  link: {
    color: "var(--accent)",
    fontSize: 12,
    textDecoration: "none",
  },
  showBtn: {
    position: "absolute", right: 6, top: "50%", transform: "translateY(-50%)",
    background: "transparent", border: "none",
    color: "var(--fg-2)", fontSize: 11, fontWeight: 500,
    cursor: "pointer", padding: "4px 8px", borderRadius: 4,
  },
  errorMsg: {
    fontSize: 11.5,
    color: "oklch(0.78 0.12 25)",
    marginTop: 5,
    display: "flex", alignItems: "center", gap: 4,
  },
};

Object.assign(window, { LoginView });
