// VIEW 3 — CALENDAR (week) VIEW
// Day columns × hour rows. Event blocks click → modal.

const CalendarView = () => {
  const data = window.SCHED_DATA;
  const days = [
    { iso: "2026-04-27", label: "Mo", num: 27 },
    { iso: "2026-04-28", label: "Di", num: 28 },
    { iso: "2026-04-29", label: "Mi", num: 29, today: true },
    { iso: "2026-04-30", label: "Do", num: 30 },
    { iso: "2026-05-01", label: "Fr",  num: 1 },
    { iso: "2026-05-02", label: "Sat",  num: 2 },
    { iso: "2026-05-03", label: "So",  num: 3 },
  ];
  const HOUR_START = 9, HOUR_END = 24;
  const HOURS = HOUR_END - HOUR_START;
  const PX_PER_HOUR = 56;

  // Flatten items with color
  const allItems = [];
  data.events.forEach(g => g.items.forEach(it => allItems.push({ ...it, color: g.color, group: g.title, groupId: g.id, icon: g.icon })));

  const [showModal, setShowModal] = React.useState(false);
  const [active, setActive] = React.useState(null);

  // Synthetic add-booking dummy (so we can show the +new modal)
  const openNew = (day, hour) => {
    setActive({ isNew: true, date: day, start: `${String(hour).padStart(2,"0")}:00`, end: `${String(hour+1).padStart(2,"0")}:00` });
    setShowModal(true);
  };

  const toMin = (h) => { const [a, b] = h.split(":").map(Number); return a * 60 + b; };
  const top = (it) => ((toMin(it.start) - HOUR_START * 60) / 60) * PX_PER_HOUR;
  const height = (it) => ((toMin(it.end) - toMin(it.start)) / 60) * PX_PER_HOUR;

  return (
    <div style={cvStyles.root}>
      <Sidebar active="schedule" />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        <header style={cvStyles.topbar}>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div>
              <div style={{ fontSize: 11, color: "var(--fg-3)", textTransform: "uppercase", letterSpacing: 0.5 }}>Planung · KW 18</div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>27. Apr – 3. Mai 2026</div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <button className="btn ghost" style={{ padding: "4px 8px" }}>‹</button>
              <button className="btn" style={{ fontSize: 12 }}>Diese Woche</button>
              <button className="btn ghost" style={{ padding: "4px 8px" }}>›</button>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={cvStyles.viewSwitch}>
              <span style={cvStyles.viewBtn}>Tag</span>
              <span style={{ ...cvStyles.viewBtn, ...cvStyles.viewActive }}>Woche</span>
              <span style={cvStyles.viewBtn}>Monat</span>
            </div>
            <button className="btn primary" style={{ fontSize: 12 }} onClick={() => { setActive(null); setShowModal(true); }}>+ Neue Buchung</button>
          </div>
        </header>

        <div style={cvStyles.toolbar}>
          <div style={{ position: "relative", width: 240 }}>
            <input className="input" placeholder="Diese Woche durchsuchen…" style={{ paddingLeft: 28, fontSize: 12 }} />
            <span style={{ position: "absolute", left: 9, top: "50%", transform: "translateY(-50%)", color: "var(--fg-3)" }}>⌕</span>
          </div>
          <button className="btn" style={{ fontSize: 12 }}>Pool 1 ▾</button>
          <div style={{ flex: 1 }} />
          <Legend />
        </div>

        <div style={{ flex: 1, overflow: "auto" }}>
          {/* Header row */}
          <div style={cvStyles.headerRow}>
            <div style={cvStyles.timeCol}> </div>
            {days.map(d => (
              <div key={d.iso} style={cvStyles.dayHead}>
                <div style={{ fontSize: 11, color: d.today ? "var(--accent)" : "var(--fg-3)", textTransform: "uppercase", letterSpacing: 0.5, fontWeight: 500 }}>{d.label}</div>
                <div style={{ fontSize: 18, fontWeight: 600, color: d.today ? "var(--accent)" : "var(--fg-0)" }}>{d.num}</div>
              </div>
            ))}
          </div>

          {/* Body */}
          <div style={cvStyles.body}>
            {/* time labels */}
            <div style={cvStyles.timeCol}>
              {Array.from({ length: HOURS }).map((_, i) => (
                <div key={i} style={{ height: PX_PER_HOUR, padding: "4px 8px", color: "var(--fg-3)", fontSize: 10.5, textAlign: "right", borderBottom: "1px solid var(--border-0)" }} className="mono">
                  {String(HOUR_START + i).padStart(2,"0")}:00
                </div>
              ))}
            </div>
            {/* day columns */}
            {days.map(d => {
              const dayItems = allItems.filter(i => i.date === d.iso);
              return (
                <div key={d.iso} style={cvStyles.dayCol}>
                  {Array.from({ length: HOURS }).map((_, i) => (
                    <div key={i}
                      onDoubleClick={() => openNew(d.iso, HOUR_START + i)}
                      style={{ height: PX_PER_HOUR, borderBottom: "1px solid var(--border-0)", borderRight: "1px solid var(--border-0)", cursor: "pointer" }}
                    />
                  ))}
                  {dayItems.map(it => (
                    <div key={it.id}
                      onClick={() => { setActive(it); setShowModal(true); }}
                      style={{
                        position: "absolute",
                        left: 4, right: 4,
                        top: top(it), height: height(it),
                        background: `color-mix(in oklch, ${it.color} 24%, var(--bg-1))`,
                        borderLeft: `3px solid ${it.color}`,
                        border: `1px solid ${it.color}`,
                        borderRadius: 5,
                        padding: "4px 7px",
                        overflow: "hidden",
                        cursor: "pointer",
                        fontSize: 11,
                      }}
                    >
                      <div style={{ fontWeight: 600, color: "var(--fg-0)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.title}</div>
                      <div className="mono" style={{ color: "var(--fg-1)", fontSize: 10.5 }}>{it.start}–{it.end}</div>
                      {height(it) > 60 && (
                        <div style={{ color: "var(--fg-2)", fontSize: 10.5, marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.destination}</div>
                      )}
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {showModal && <BookingModal item={active} onClose={() => setShowModal(false)} />}
    </div>
  );
};

const BookingModal = ({ item, onClose }) => {
  const isNew = !item || item.isNew;
  const [form, setForm] = React.useState({
    title: item?.title || "",
    event: item?.group || "",
    date: item?.date || "2026-04-29",
    start: item?.start || "10:00",
    end: item?.end || "11:00",
    source: item?.source || "",
    destination: item?.destination || "",
    workflow: item?.workflow || "Export to AVID",
  });
  const upd = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div style={cvStyles.modalBg} onClick={onClose}>
      <div style={cvStyles.modal} onClick={(e) => e.stopPropagation()}>
        <div style={cvStyles.modalHead}>
          <div>
            <div style={{ fontSize: 11, color: "var(--fg-3)", textTransform: "uppercase", letterSpacing: 0.5 }}>{isNew ? "Neue Buchung" : "Buchung bearbeiten"}</div>
            <div style={{ fontWeight: 600, fontSize: 16, marginTop: 2 }}>{isNew ? "Neue Aufnahme planen" : item.title}</div>
          </div>
          <button className="btn ghost" style={{ padding: 6 }} onClick={onClose}>✕</button>
        </div>
        <div style={cvStyles.modalBody}>
          <Field label="Titel" full>
            <input className="input" value={form.title} placeholder="z. B. Bundesliga-Spiel · 1. Halbzeit" onChange={e => upd("title", e.target.value)} />
          </Field>
          <Field label="Ereignis">
            <select className="select" value={form.event} onChange={e => upd("event", e.target.value)}>
              <option value="">Ereignis wählen…</option>
              {window.SCHED_DATA.events.map(e => <option key={e.id}>{e.title}</option>)}
            </select>
          </Field>
          <Field label="Status">
            <StatusChip status="draft" />
          </Field>
          <Field label="Datum" required>
            <input className="input mono" type="date" value={form.date} onChange={e => upd("date", e.target.value)} />
          </Field>
          <Field label="Beginn" required>
            <input className="input mono" type="time" value={form.start} onChange={e => upd("start", e.target.value)} />
          </Field>
          <Field label="Ende" required>
            <input className="input mono" type="time" value={form.end} onChange={e => upd("end", e.target.value)} />
          </Field>
          <Field label="Quelle" required>
            <select className="select" value={form.source} onChange={e => upd("source", e.target.value)}>
              <option value="">Quelle wählen…</option>
              {window.SCHED_DATA.sources.map(s => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Ziel" required>
            <select className="select" value={form.destination} onChange={e => upd("destination", e.target.value)}>
              <option value="">Ziel wählen…</option>
              {window.SCHED_DATA.destinations.map(s => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Workflow-Vorlage">
            <select className="select" value={form.workflow} onChange={e => upd("workflow", e.target.value)}>
              {window.SCHED_DATA.workflows.map(s => <option key={s}>{s}</option>)}
            </select>
          </Field>
        </div>
        <div style={cvStyles.modalFoot}>
          <span style={{ fontSize: 11, color: "var(--fg-3)" }}>⚐ Zeitfenster verfügbar — keine Konflikte erkannt.</span>
          <div style={{ flex: 1 }} />
          <button className="btn" onClick={onClose}>Abbrechen</button>
          <button className="btn primary" onClick={onClose}>{isNew ? "Buchung erstellen" : "Speichern"}</button>
        </div>
      </div>
    </div>
  );
};

const cvStyles = {
  root: { display: "flex", height: "100%", background: "var(--bg-0)", position: "relative" },
  topbar: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 16px", borderBottom: "1px solid var(--border-0)" },
  viewSwitch: { display: "flex", padding: 2, borderRadius: 6, background: "var(--bg-2)", border: "1px solid var(--border-0)", fontSize: 11.5 },
  viewBtn: { padding: "3px 10px", borderRadius: 4, color: "var(--fg-2)" },
  viewActive: { background: "var(--bg-4)", color: "var(--fg-0)", fontWeight: 500 },
  toolbar: { display: "flex", alignItems: "center", gap: 8, padding: "8px 14px", borderBottom: "1px solid var(--border-0)" },
  headerRow: { display: "flex", position: "sticky", top: 0, zIndex: 5, background: "var(--bg-1)", borderBottom: "1px solid var(--border-0)" },
  timeCol: { width: 60, flex: "0 0 60px", borderRight: "1px solid var(--border-0)", background: "var(--bg-1)" },
  dayHead: { flex: 1, padding: "10px 12px", borderLeft: "1px solid var(--border-0)" },
  body: { display: "flex", minHeight: 0 },
  dayCol: { flex: 1, position: "relative", minWidth: 0 },
  modalBg: { position: "absolute", inset: 0, background: "oklch(0 0 0 / 0.55)", display: "grid", placeItems: "center", zIndex: 100 },
  modal: { width: 540, background: "var(--bg-1)", border: "1px solid var(--border-0)", borderRadius: 10, boxShadow: "0 20px 60px oklch(0 0 0 / 0.5)", display: "flex", flexDirection: "column", maxHeight: "90%" },
  modalHead: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", padding: "16px 18px 14px", borderBottom: "1px solid var(--border-0)" },
  modalBody: { padding: 18, display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px 16px", overflow: "auto" },
  modalFoot: { display: "flex", alignItems: "center", gap: 8, padding: "12px 18px", borderTop: "1px solid var(--border-0)", background: "var(--bg-0)" },
};

Object.assign(window, { CalendarView });
