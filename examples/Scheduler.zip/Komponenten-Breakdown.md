# Scheduler · Komponenten-Breakdown

Logisch geschnittene Bausteine pro Ansicht — als Grundlage für eine Web-Components-Implementierung. Jede Komponente nennt ihre Rolle, den Zweck, Props/Attribute, Events sowie die Komponenten, aus denen sie sich zusammensetzt.

**Rollen-Konvention:** `Atom` (kleinste UI-Einheit) · `Molecule` (kombinierte Atome mit klarer Funktion) · `Organism` (eigenständige Funktions-Einheit) · `Layout` (Strukturkomponente).

---

## Inhalt

- [00 · Shared / Chrome](#00--shared--chrome)
- [01 · Login](#01--login)
- [02 · Timeline / Gantt](#02--timeline--gantt)
- [03 · Tabelle / Detail](#03--tabelle--detail)
- [04 · Kalender (Woche)](#04--kalender-woche)
- [05 · Pools × Devices](#05--pools--devices)

---

## 00 · Shared / Chrome

View-übergreifende Bausteine, die in jeder Ansicht eingesetzt werden. Bildet die Basis-Schicht der Komponenten-Bibliothek.

### `<sched-app-shell>` — *Layout*

Wurzel-Layout der Applikation. Hält Sidebar links, Hauptbereich rechts. Liefert globalen Hintergrund (Token `--bg-0`) und Schriftrendering. Routed via Slot oder URL-Hash zu den View-Komponenten.

| | |
|---|---|
| **Slots** | `default` (View) |
| **Attribute** | `route` (login\|timeline\|table\|calendar\|pools) |

### `<sched-view-shell>` — *Layout*

Innerer View-Container. Vertikal gestapelt: Topbar → Toolbar → Body. Wird von jeder konkreten View-Komponente als Hülle verwendet, um Padding, Border-Tokens und Scroll-Verhalten konsistent zu halten.

| | |
|---|---|
| **Slots** | `topbar`, `toolbar`, `default` (body), `footer` |

### `<sched-sidebar>` — *Organism*

Linke Navigation. Brand-Mark oben, Hauptnavigation (Pool / Timeline / Schedule / Sources / Workflows / Archive), unten User-Card mit Avatar.

| | |
|---|---|
| **Enthält** | `<sched-brand-mark>` · `<sched-nav-item>` ×n · `<sched-user-card>` |
| **Props** | `active` (route key), `user` |
| **Events** | `nav-change` (detail: `{route}`) |

#### Bestandteile

##### `<sched-nav-item>` — *Molecule*

Einzelner Navigations-Eintrag mit Icon und Label. States: default, hover, active. Aktiv-State mit hellerem Surface (`--bg-3`) und kräftigerem Foreground.

| | |
|---|---|
| **Attribute** | `icon`, `label`, `route`, `active` |

##### `<sched-user-card>` — *Molecule*

User-Karte am unteren Sidebar-Rand. Avatar + Name + Rolle, klickbar für User-Menü.

| | |
|---|---|
| **Enthält** | `<sched-avatar>` |
| **Events** | `menu-open` |

##### `<sched-avatar>` — *Atom*

Runder Avatar mit Initialen oder Bild. Gradient-Fallback auf Akzentfarbe. Größenvarianten `xs/sm/md`.

### `<sched-status-chip>` — *Atom*

Pille mit Farbpunkt für Status (Live, Geplant, Bereit, Abgeschlossen, Running, Recording). View-übergreifend wiederverwendet (Tabelle, Timeline, Pools, Detail). Live-Status mit weichem Pulsglow.

| | |
|---|---|
| **Attribute** | `status="live"\|"scheduled"\|"draft"\|"complete"\|"running"\|"recording"` |

### `<sched-button>` — *Atom*

Generischer Button. Varianten: `default`, `primary`, `ghost`, `danger`. Größen `sm/md`. `disabled`-State mit reduzierter Opazität.

| | |
|---|---|
| **Attribute** | `variant`, `size`, `disabled`, `icon` |

### `<sched-input>` — *Atom*

Styled Text-Input. Varianten: text, mono, icon-prefix. Focus-Ring in Akzentfarbe. Wird mit `<sched-form-field>` zu vollständigen Feldern kombiniert.

### `<sched-icon>` — *Atom*

Unicode-/Glyph-basiertes Mini-Icon (bewusst zurückhaltend gewählt). Konsistente Größe und Farb-Inheritance via `currentColor`.

---

## 01 · Login

Authentifizierungs-Einstieg. Geteiltes Layout mit Live-Vorschau-Hero links und Formular rechts. Validation, Passwort-Sichtbarkeit, Remember-Me und SSO-Provider sind in eigenständigen Komponenten gekapselt.

### `<sched-login-split>` — *Layout*

Zweispaltiges Layout der Login-Seite. Linke Spalte: Marketing/Branding-Panel mit Live-Status-Vorschau. Rechte Spalte: Formular-Container. Auf schmalen Viewports einspaltig (Hero ausgeblendet).

| | |
|---|---|
| **Enthält** | `<sched-login-hero>` · `<sched-login-form>` |
| **Slots** | `hero`, `form` (beide optional, default-Inhalt vorhanden) |

### `<sched-login-hero>` — *Organism*

Linkes Panel der Split-Variante. Zeigt Brand, Headline, Subline, eine Live-Status-Vorschau (3 Pool-Bars) und Footer-Copyright. Reine Präsentation — keine Interaktion.

| | |
|---|---|
| **Enthält** | `<sched-brand-mark>` · `<sched-preview-bar>` ×n |
| **Props** | `headline`, `subline`, `previewItems` (Array) |

### `<sched-preview-bar>` — *Molecule*

Schmaler horizontaler Statusbalken für die Hero-Vorschau. Pool-Label, gefüllter Balken mit Status-Farbe (recording / running / planned) und Item-Titel. Animiert dezent, um „lebendiges System" zu suggerieren.

| | |
|---|---|
| **Attribute** | `label`, `pool`, `status`, `width` (0–100 %) |

### `<sched-login-form>` — *Organism*

Das eigentliche Formular. Verwaltet State (E-Mail, Passwort, Remember-Me, Touched/Submitted-Flags), Validierung und Submit-Handling. Nutzt Sub-Komponenten für Feld + Fehler, Passwort-Toggle, SSO-Provider und Erfolgs-Banner.

| | |
|---|---|
| **Props** | `centered` (Bool, ändert Text-Alignment) |
| **Events** | `submit` · `sso-select` (detail: provider) · `request-account` |
| **Validierung** | E-Mail-Regex, Passwort min. 8 Zeichen, Pflichtfeld-Checks |

#### Bestandteile

##### `<sched-form-field>` — *Molecule*

Wrapper aus Label + Input + Fehlertext. Übernimmt Border-Färbung im Fehlerzustand und blendet die Meldung ein. Wiederverwendbar für E-Mail und alle weiteren Eingaben.

| | |
|---|---|
| **Attribute** | `label`, `type`, `placeholder`, `error`, `required` |
| **Slots** | `suffix` (z. B. für Passwort-Toggle) |

##### `<sched-password-field>` — *Molecule*

Spezialisierung von `<sched-form-field>` mit Passwort-Toggle („Anzeigen"/„Verbergen") rechts im Input und „Vergessen?"-Link über dem Label.

| | |
|---|---|
| **Events** | `forgot-click` |

##### `<sched-checkbox>` — *Atom*

Custom-Checkbox mit Label. Hier: „Auf diesem Gerät angemeldet bleiben". Akzentfarbe folgt dem Token `--accent`.

##### `<sched-divider>` — *Atom*

Trennlinie mit zentriertem Text („oder fortfahren mit"). Reine Layout-Hilfe.

##### `<sched-sso-buttons>` — *Molecule*

Zwei-Spalten-Grid mit SSO-Providern (RTL-SSO, Microsoft). Emittiert beim Klick `sso-select` mit Provider-Kennung.

| | |
|---|---|
| **Props** | `providers` (Array `{id, label, hint}`) |
| **Events** | `sso-select` (detail: `{provider}`) |

##### `<sched-banner>` — *Atom*

Statusbanner für Erfolgs-/Fehler-/Hinweis-Zustände (z. B. „✓ Authentifiziert · Weiterleitung zur Timeline…"). Wird auch in anderen Views genutzt.

| | |
|---|---|
| **Attribute** | `tone="success"\|"error"\|"info"` |

### `<sched-brand-mark>` — *Atom*

Logo-Komponente: Gradient-Quadrat mit „S" plus Wortmarke und Subtitel („Ingest Ops · v4.2"). In Login (groß), Sidebar (klein) und Print-Footer (Mono) wiederverwendet.

| | |
|---|---|
| **Attribute** | `size="sm"\|"md"\|"lg"` · `subtitle` (optional) |

---

## 02 · Timeline / Gantt

Tagesansicht über eine Stundenleiste. Jede Event-Gruppe ist eine horizontale Spur (Lane) mit positionierten Item-Bars. Drag-and-Drop verschiebt Items und snappt auf 15 Minuten. Rechts ein Detailpanel mit Routing-Info und Konfliktprüfung.

### `<sched-timeline-view>` — *Layout*

Layout-Komponente mit Sidebar links und gestapeltem Hauptbereich: Topbar → Toolbar → (Lanes-Bereich + Detail-Panel). Verwaltet Drag-State, aktives Item, Filter und die berechneten Items des Tages.

| | |
|---|---|
| **Enthält** | `<sched-sidebar>` · `<sched-timeline-topbar>` · `<sched-timeline-toolbar>` · `<sched-timeline-grid>` · `<sched-timeline-detail>` |
| **State** | `items`, `activeId`, `filter`, `now` (Stunden-Float) |
| **Konstanten** | `HOUR_START=10`, `HOUR_END=24`, `PX_PER_HOUR=88`, `SNAP_MIN=15` |

### `<sched-timeline-topbar>` — *Organism*

Topbar mit Datums-Eyebrow + aktuellem Sendetag, Datums-Navigation (‹/Heute/›), Zoom-Switch (Tag/Stunden/15min) und CTA „+ Neue Buchung".

| | |
|---|---|
| **Enthält** | `<sched-date-stepper>` · `<sched-zoom-switch>` |
| **Events** | `date-change`, `zoom-change`, `add-booking` |

### `<sched-date-stepper>` — *Molecule*

Drei-teiliger Datums-Navigator: Vor-/Zurück-Buttons mit zentralem „Heute"-Reset. Auch in Calendar-View wiederverwendet (Label dort „Diese Woche").

| | |
|---|---|
| **Attribute** | `resetLabel`, `step="day"\|"week"\|"month"` |

### `<sched-zoom-switch>` — *Atom*

Segmentierter Switch für Zoom-Stufen (Tag/Stunden/15min). Generischer Segment-Button-Group; ebenfalls für Tag/Woche/Monat in der Calendar-View nutzbar.

### `<sched-timeline-toolbar>` — *Organism*

Filterleiste: Suchfeld, Quellen-/Pool-Filter-Dropdowns, Farb-Legende der Event-Gruppen und Tastatur-Hint („Zum Verschieben ziehen").

| | |
|---|---|
| **Enthält** | `<sched-search-input>` · `<sched-filter-dropdown>` ×n · `<sched-legend>` · `<sched-kbd>` |

### `<sched-legend>` — *Molecule*

Inline-Legende: Farbquadrat + Label pro Event-Gruppe. Datengetrieben über `entries`-Prop.

### `<sched-kbd>` — *Atom*

Keyboard-/Hint-Pille im Mono-Font. Auch für Shortcut-Hints verwendbar.

### `<sched-timeline-grid>` — *Organism*

Kern der Ansicht: Stunden-Lineal oben, vertikal gestapelte Lanes, Now-Line über alle Lanes. Akzeptiert Lanes + Items, kapselt Drag-Logik (Pixel→Zeit-Konversion, Snap auf 15min).

| | |
|---|---|
| **Enthält** | `<sched-hour-ruler>` · `<sched-timeline-lane>` ×n · `<sched-now-line>` |
| **Props** | `lanes`, `items`, `activeId`, `hourStart`, `hourEnd`, `pxPerHour`, `snapMin` |
| **Events** | `item-move` (detail: `{id, start, end}`) · `item-activate` |

#### Bestandteile

##### `<sched-hour-ruler>` — *Atom*

Horizontale Stundenleiste. Rendert Zeit-Labels alle `PX_PER_HOUR` Pixel mit Trennlinien. Einheitlich in Timeline und Pools genutzt.

##### `<sched-timeline-lane>` — *Organism*

Eine Spur: links Lane-Label (Event-Badge, Titel, Anzahl), rechts Drop-Zone-Canvas mit Stundenraster und Item-Bars. Empfängt Drag-Events und delegiert `item-move` nach oben.

| | |
|---|---|
| **Attribute** | `lane`, `items`, `activeId` |

##### `<sched-timeline-item>` — *Molecule*

Item-Bar: positioniert über `left/width`, Farbe von der Lane geerbt (Mix-Blend mit Surface). Zeigt Titel, Zeitspanne, und ab Breite > 140px zusätzlich Quelle → Ziel. Draggable. Aktiv-State mit Akzent-Outline und Drop-Schatten.

| | |
|---|---|
| **Attribute** | `item`, `color`, `active`, `x`, `width` |

##### `<sched-now-line>` — *Atom*

Vertikale „Jetzt"-Markierung über alle Lanes mit kleinem Punkt am Kopf. Auto-Update via `now`-Prop oder interner Tick-Timer.

### `<sched-timeline-detail>` — *Organism*

Rechtes Detailpanel zum aktiven Item: Header mit Event-Badge, Gruppentitel, Item-Titel, Status-Chip. Sektionen für Zeit-Info und Routing (Quelle/Ziel/Workflow). Aktionen Open/Edit und Konfliktprüfungs-Block mit Auslastungs-Indikator.

| | |
|---|---|
| **Enthält** | `<sched-detail-row>` ×n · `<sched-status-chip>` · `<sched-conflict-card>` |
| **Props** | `item` |
| **Events** | `open`, `edit` |

#### Bestandteile

##### `<sched-detail-row>` — *Atom*

Label/Wert-Zeile mit Trennlinie unten. Wert kann reiner Text oder ausgezeichnetes Mono-Snippet (Codes, Zeiten) sein.

##### `<sched-conflict-card>` — *Molecule*

Hinweis-Box mit Flag-Icon, Konflikt-Status und numerischem Auslastungs-Wert. Tones: ok, warn, error.

| | |
|---|---|
| **Attribute** | `tone`, `resource`, `utilization` (0–1) |

---

## 03 · Tabelle / Detail

Hierarchische Tabelle (Gruppen → Items) mit Mehrfachauswahl, Filter, Gruppierung und Sortierung. Unten ein an die aktive Zeile gekoppeltes Detailformular mit Tabs für Spezifikation und Metadaten.

### `<sched-table-view>` — *Layout*

Seiten-Layout der Tabellenansicht. Sidebar links, Hauptbereich rechts mit vertikaler Stapelung: Topbar → Toolbar → Tabelle → Detailformular. Verwaltet Cross-Component-State (aktives Item, Auswahl, Filter, Sortierung, kollabierte Gruppen).

| | |
|---|---|
| **Enthält** | `<sched-sidebar>` · `<sched-table-topbar>` · `<sched-table-toolbar>` · `<sched-booking-table>` · `<sched-spec-panel>` |
| **State** | `activeItem`, `selected` (Set), `collapsed`, `query`, `sortKey` |

### `<sched-table-topbar>` — *Organism*

Kontext-Topbar: Zurück-Link zur Timeline, Kategorie-Eyebrow + Titel, View-Switch zwischen „Definition"/„Komponenten" und Schließen-Button.

| | |
|---|---|
| **Props** | `title`, `eyebrow`, `view` (definition\|components) |
| **Events** | `back`, `view-change`, `close` |

### `<sched-table-toolbar>` — *Organism*

Aktionsleiste über der Tabelle: Suchfeld, Gruppierungs-Auswahl, Auswahl-Counter, Bulk-Aktionen (Duplizieren, Löschen) und Primär-CTA „+ Booking hinzufügen". Bulk-Buttons sind disabled wenn keine Auswahl besteht.

| | |
|---|---|
| **Enthält** | `<sched-search-input>` · `<sched-group-by>` · Action-Buttons |
| **Events** | `query-change`, `group-change`, `bulk-duplicate`, `bulk-delete`, `add-booking` |

### `<sched-search-input>` — *Molecule*

Eingabefeld mit vorangestelltem Lupensymbol. Debounced `query-change`-Event. Auch in Pools/Calendar einsetzbar.

| | |
|---|---|
| **Attribute** | `placeholder`, `value`, `debounce` (ms) |

### `<sched-booking-table>` — *Organism*

Die Kerntabelle. Sticky Spaltenkopf, virtualisierter Body (für lange Listen), Gruppen-Zeilen mit Klick zum Auf-/Zuklappen. Akzeptiert die gefilterte/sortierte Datenstruktur als Input.

| | |
|---|---|
| **Enthält** | `<sched-table-header>` · `<sched-table-group-row>` · `<sched-table-row>` |
| **Props** | `groups`, `activeId`, `selected`, `collapsed` |
| **Events** | `row-activate`, `row-toggle-select`, `group-toggle`, `sort-change` |

#### Bestandteile

##### `<sched-table-header>` — *Molecule*

Spaltenkopf mit klickbaren Sortier-Indikatoren (↓/↑). Spaltendefinition deklarativ über `columns`-Prop.

##### `<sched-table-group-row>` — *Molecule*

Gruppen-Header-Zeile: Caret-Icon, Event-Badge mit Farbe und Initialen, Titel, Item-Anzahl, „+ Komponente hinzufügen"-Aktion. Klick togglt collapse.

| | |
|---|---|
| **Attribute** | `title`, `icon`, `color`, `count`, `collapsed` |

##### `<sched-table-row>` — *Molecule*

Item-Zeile. Checkbox, Farb-Akzentstreifen (von der Gruppe geerbt), Titel, Datum/Zeit/Dauer in Mono, Quelle/Ziel/Workflow, Status-Chip, Inline-Aktionen (Duplizieren, Bearbeiten). States: default, selected, active.

| | |
|---|---|
| **Attribute** | `item`, `group-color`, `selected`, `active` |

### `<sched-spec-panel>` — *Organism*

Detailformular am unteren Bildschirmrand. Tabs für Spezifikation und Metadaten, „Bearbeite <ID>"-Anzeige, Footer mit Audit-Hinweis und Abbrechen/Speichern-Aktionen.

| | |
|---|---|
| **Enthält** | `<sched-tabs>` · `<sched-spec-form>` · `<sched-metadata-form>` |
| **Props** | `item`, `tab` |
| **Events** | `save`, `cancel`, `tab-change` |

#### Bestandteile

##### `<sched-tabs>` — *Atom*

Generische Tab-Leiste (auch in Pools für Pool/Device/Workflow wiederverwendet). Slot-basiert oder via `tabs`-Array.

##### `<sched-spec-form>` — *Organism*

Spezifikations-Formular mit Grid aus `<sched-field>`-Komponenten: Status, Item-ID, Chip-ID, Chunk-ID, Start-/Enddatum & -zeit, Dauer. Mono-Inputs für Codes/Zeiten.

##### `<sched-metadata-form>` — *Organism*

Read-only-orientierte Metadaten-Liste (Erstellt, Geändert, Verantwortlich, Tags, Bitrate, Codec, Audio, Notizen). Notizen als mehrzeiliger Textbereich.

##### `<sched-field>` — *Molecule*

Generischer Form-Feld-Wrapper mit Label, optionalem Hinweis-Tooltip (ⓘ), Pflichtfeld-Marker und Slot für Input/Custom-Control. Variante `full` spannt sich über zwei Spalten.

| | |
|---|---|
| **Attribute** | `label`, `required`, `hint`, `full` |
| **Slots** | `default` (Input), `icon` (rechts im Feld) |

---

## 04 · Kalender (Woche)

Wochenansicht mit 7 Tag-Spalten × Stunden-Reihen. Items sind absolut positionierte Blöcke. Doppelklick auf eine leere Zelle öffnet ein Modal zum Anlegen einer neuen Buchung; Klick auf ein bestehendes Item öffnet es zum Bearbeiten.

### `<sched-calendar-view>` — *Layout*

Layout der Wochenansicht. Sidebar links, vertikal gestapelt: Topbar → Toolbar → Wochen-Grid. Verwaltet Modal-Sichtbarkeit und das aktuell bearbeitete/neue Item.

| | |
|---|---|
| **Enthält** | `<sched-sidebar>` · `<sched-calendar-topbar>` · `<sched-calendar-toolbar>` · `<sched-week-grid>` · `<sched-booking-modal>` |
| **State** | `showModal`, `active` (Item oder `{isNew, date, start, end}`) |

### `<sched-calendar-topbar>` — *Organism*

Topbar: KW-Eyebrow + Datumsspanne, Wochen-Stepper, Tag/Woche/Monat-Switch und Primär-CTA „+ Neue Buchung".

| | |
|---|---|
| **Enthält** | `<sched-date-stepper>` · `<sched-zoom-switch>` |
| **Events** | `week-change`, `zoom-change`, `add-booking` |

### `<sched-calendar-toolbar>` — *Organism*

Toolbar mit Suchfeld („Diese Woche durchsuchen…"), Pool-Filter und Farb-Legende. Wiederverwendet `<sched-search-input>` und `<sched-legend>` aus der Timeline.

### `<sched-week-grid>` — *Organism*

Das Wochengitter. Sticky Tages-Header oben, Zeit-Spalte links, 7 Tag-Spalten als Drop-/Klickflächen mit absolut positionierten Item-Karten. Doppelklick emittiert `cell-create` mit (Datum, Stunde).

| | |
|---|---|
| **Enthält** | `<sched-week-header>` · `<sched-time-col>` · `<sched-day-col>` ×7 · `<sched-event-card>` |
| **Props** | `days`, `items`, `hourStart`, `hourEnd`, `pxPerHour` |
| **Events** | `cell-create` (detail: `{date, hour}`) · `item-open` |

#### Bestandteile

##### `<sched-week-header>` — *Molecule*

Sticky Kopfzeile mit Wochentag-Kürzel und Datum pro Spalte. Hebt den heutigen Tag mit Akzentfarbe hervor.

| | |
|---|---|
| **Attribute** | `days` (Array `{iso, label, num, today}`) |

##### `<sched-time-col>` — *Atom*

Linke Zeit-Achse mit stündlichen Mono-Labels. Höhe pro Stunde folgt `pxPerHour` — bestimmt die Item-Skalierung.

##### `<sched-day-col>` — *Organism*

Spalte für einen Tag. Stündliche Klick-Zellen (Doppelklick → neuer Eintrag) und übereinander gelegte Event-Karten an berechneter Position.

| | |
|---|---|
| **Attribute** | `day`, `items` |

##### `<sched-event-card>` — *Molecule*

Item-Karte im Kalender. Farb-Akzentstreifen links, Titel, Mono-Zeitspanne und (ab Höhe > 60px) Ziel. Klick öffnet Bearbeiten-Modal.

| | |
|---|---|
| **Attribute** | `item`, `color`, `top`, `height` |

### `<sched-booking-modal>` — *Organism*

Modal-Dialog zum Anlegen oder Bearbeiten einer Buchung. Header mit Eyebrow + Titel, zweispaltiges Formular-Grid, Footer mit Konflikt-Hinweis und Aktionen (Abbrechen / Erstellen | Speichern). Schließt bei Klick auf den Hintergrund.

| | |
|---|---|
| **Enthält** | `<sched-modal-shell>` · `<sched-field>` ×n · `<sched-status-chip>` |
| **Props** | `item` (oder leer für „neu"), `events`, `sources`, `destinations`, `workflows` |
| **Events** | `save` (detail: form) · `cancel` |

#### Bestandteile

##### `<sched-modal-shell>` — *Layout*

Generische Modal-Hülle: Backdrop, zentrierte Karte, ESC-Handling, Click-outside-to-close. Slots für Header, Body, Footer. Wiederverwendbar für jede modale Aktion.

| | |
|---|---|
| **Slots** | `header`, `default` (body), `footer` |
| **Attribute** | `width`, `open` |

##### `<sched-select>` — *Atom*

Styled Select für Ereignis/Quelle/Ziel/Workflow. Folgt den gleichen Tokens wie `<sched-input>` (Border, Focus-Ring, Akzentfarbe). Akzeptiert `options`-Array oder Slot-Children.

---

## 05 · Pools × Devices

Operative Live-Sicht auf Aufnahme-Kapazitäten. Pools als kollabierbare Gruppen, jedes Pool enthält mehrere Device-Spuren mit ihren Item-Bars über 24 Stunden. Stunden-Lineal mit 15-Minuten-Subtick, Playhead markiert die aktuelle Zeit. Hover zeigt Detail-Tooltip.

### `<sched-pools-view>` — *Layout*

Layout der Pools-Ansicht. Sidebar links, vertikal gestapelt: Topbar → Sub-Bar → Stunden-Lineal → scrollende Pool-Liste → Footer. Verwaltet kollabierten Status pro Pool und das aktuell gehoverte Item.

| | |
|---|---|
| **Enthält** | `<sched-sidebar>` · `<sched-pools-topbar>` · `<sched-pools-subbar>` · `<sched-pools-ruler>` · `<sched-pool-group>` ×n · `<sched-pools-footer>` |
| **State** | `collapsed`, `hoverItem` |
| **Konstanten** | `HOUR_START=0`, `HOUR_END=24`, `PX_PER_HOUR=70`, `PLAYHEAD_HOUR=8.0` |

### `<sched-pools-topbar>` — *Organism*

Topbar mit Sektion-Eyebrow + aktuellem Datum/Zeitfenster, Quick-Actions (Zurücksetzen, Zu Datum springen, Zu Zeit springen) und Filter-/Einstellungs-Knöpfen rechts.

| | |
|---|---|
| **Events** | `reset`, `jump-date`, `jump-time`, `filter-open`, `settings-open` |

### `<sched-pools-subbar>` — *Organism*

Zweite Leiste mit Gruppierungs-Tabs (Pool / Device / Workflow) und einem Quick-Recording-Select rechts.

| | |
|---|---|
| **Enthält** | `<sched-tabs>` · `<sched-select>` |
| **Events** | `group-by-change`, `quick-record-select` |

### `<sched-pools-ruler>` — *Organism*

Sticky Stunden-Lineal mit 15-Min-Subticks, Stunden-Labels im HH:MM:SS-Format und einem prominenten Akzent-Playhead samt Knubbel oben. Spannt sich über alle Device-Lanes.

| | |
|---|---|
| **Enthält** | `<sched-playhead>` |
| **Props** | `hourStart`, `hourEnd`, `pxPerHour`, `playhead` (Stunden-Float) |

### `<sched-playhead>` — *Atom*

Vertikale Akzent-Linie mit Kopf-Punkt im Lineal. Im Lane-Bereich erscheint sie schmaler und mit reduzierter Opazität, um nicht mit Item-Bars zu konkurrieren. Auto-Update via Tick-Timer optional.

### `<sched-pool-group>` — *Organism*

Eine Pool-Gruppe. Pool-Header (klickbar zum Auf-/Zuklappen) plus eine Liste von Device-Spuren. Gibt Klick zum Togglen nach oben weiter.

| | |
|---|---|
| **Enthält** | `<sched-pool-header>` · `<sched-device-row>` ×n |
| **Attribute** | `pool`, `collapsed` |

#### Bestandteile

##### `<sched-pool-header>` — *Molecule*

Header-Zeile einer Pool-Gruppe: Caret, Pool-Name, optionaler Untertitel, Geräteanzahl und eine kompakte Auslastungs-Anzeige (Capacity-Bar + %). Bei > 80 % wechselt die Bar auf Warn-Farbe.

| | |
|---|---|
| **Enthält** | `<sched-capacity-bar>` |
| **Attribute** | `name`, `subtitle`, `deviceCount`, `capacity` (0–100) |

##### `<sched-capacity-bar>` — *Atom*

Kompakter horizontaler Auslastungs-Balken mit numerischem Prozent-Wert. Token-getrieben für Ok/Warn-Farben.

| | |
|---|---|
| **Attribute** | `percent` (0–100), `warnAt` (default 80) |

##### `<sched-device-row>` — *Organism*

Eine Device-Spur. Links Device-Label mit Online-Indikator-Punkt (grün = online, grau = offline), rechts Lane-Canvas mit Stundenraster, Playhead und positionierten Item-Bars.

| | |
|---|---|
| **Enthält** | `<sched-device-label>` · `<sched-pool-item>` ×n · `<sched-pool-tooltip>` |
| **Attribute** | `device`, `items`, `hoverKey` |

##### `<sched-device-label>` — *Molecule*

Linkes Spur-Label: Online-Status-Punkt + Gerätename. Hält feste Breite, damit alle Lanes vertikal aligned bleiben.

| | |
|---|---|
| **Attribute** | `name`, `online` |

##### `<sched-pool-item>` — *Molecule*

Item-Bar im Pool-Lane. Status-spezifische Farbpalette (complete / running / recording / planned / scheduled), Live-Dot bei Aufnahme, ∞-Glyph bei verlinktem Eintrag, kompakter „EINTRAG: …"-Titel. Hover hebt mit Box-Shadow und z-Index hervor.

| | |
|---|---|
| **Attribute** | `item`, `status`, `x`, `width`, `linked` |
| **Events** | `hover`, `activate` |

##### `<sched-pool-tooltip>` — *Atom*

Schwebender Detail-Tooltip rechts neben dem gehoverten Item. Zeigt Endzeit, Dauer und Item-Label im Mono-Font. `pointer-events: none`, um Hover nicht zu unterbrechen.

### `<sched-pools-footer>` — *Organism*

Persistenter Footer mit Copyright, „+ Create booking"-Action, Messages-Inbox-Button mit Counter-Badge und großer Mono-Uhr („Mo 24.05.26 · 08:00:00"). Zeigt System-Zeit live an.

| | |
|---|---|
| **Enthält** | `<sched-inbox-button>` · `<sched-clock>` |
| **Events** | `create-booking`, `open-messages` |

### `<sched-inbox-button>` — *Molecule*

Ghost-Button mit Icon und numerischem Counter-Badge in Akzentfarbe. Blendet Badge bei Wert 0 aus.

| | |
|---|---|
| **Attribute** | `label`, `icon`, `count` |

### `<sched-clock>` — *Atom*

Live-Uhr im Mono-Font mit Wochentag, Datum und Sekunden-genauer Zeit. Eigenständiger Tick-Timer (1 s).

---

## Anhang · Wiederverwendung über Views

| Komponente | Login | Timeline | Tabelle | Kalender | Pools |
|---|:---:|:---:|:---:|:---:|:---:|
| `<sched-sidebar>` | – | ✓ | ✓ | ✓ | ✓ |
| `<sched-status-chip>` | – | ✓ | ✓ | ✓ | ✓ |
| `<sched-search-input>` | – | ✓ | ✓ | ✓ | – |
| `<sched-legend>` | – | ✓ | – | ✓ | – |
| `<sched-date-stepper>` | – | ✓ | – | ✓ | – |
| `<sched-zoom-switch>` | – | ✓ | – | ✓ | – |
| `<sched-tabs>` | – | – | ✓ | – | ✓ |
| `<sched-field>` | – | – | ✓ | ✓ | – |
| `<sched-select>` | – | – | – | ✓ | ✓ |
| `<sched-brand-mark>` | ✓ | (Sidebar) | (Sidebar) | (Sidebar) | (Sidebar) |
| `<sched-button>` | ✓ | ✓ | ✓ | ✓ | ✓ |
| `<sched-input>` | ✓ | ✓ | ✓ | ✓ | – |

---

*Generiert aus dem Scheduler-Designsystem · v1.0*
