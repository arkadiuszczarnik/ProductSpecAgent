// Shared mock data for the scheduler prototypes.
// All times are local; dates are ISO yyyy-mm-dd.

window.SCHED_DATA = (function () {
  const events = [
    {
      id: "evt-bundesliga",
      title: "Bundesliga · Matchday 32",
      color: "var(--accent)",
      icon: "B",
      items: [
        { id: "BL-32-001", chip: "DKXX-BL32-001", chunk: "JD41-001", title: "Pre-match feed", source: "Sat · Eutelsat 9B", destination: "Pool 1 · Rec 04", workflow: "Export to AVID", date: "2026-04-29", start: "11:45", end: "13:55", duration: "02:10:00", status: "live" },
        { id: "BL-32-002", chip: "DKXX-BL32-002", chunk: "JD41-002", title: "Match · 1st half", source: "Cam 1 · IRD 2", destination: "Pool 1 · Rec 04", workflow: "Export to AVID", date: "2026-04-29", start: "14:00", end: "14:50", duration: "00:50:00", status: "scheduled" },
        { id: "BL-32-003", chip: "DKXX-BL32-003", chunk: "JD41-003", title: "Match · 2nd half", source: "Cam 1 · IRD 2", destination: "Pool 1 · Rec 04", workflow: "Export to AVID, Storage A", date: "2026-04-29", start: "15:05", end: "15:55", duration: "00:50:00", status: "scheduled" },
        { id: "BL-32-004", chip: "DKXX-BL32-004", chunk: "JD41-004", title: "Post-match interviews", source: "Cam 2 · IRD 3", destination: "Pool 7 · Rec 56", workflow: "Export to AVID", date: "2026-04-29", start: "16:00", end: "16:30", duration: "00:30:00", status: "scheduled" },
      ],
    },
    {
      id: "evt-champions",
      title: "Champions League · Quarterfinal",
      color: "oklch(0.72 0.12 290)",
      icon: "C",
      items: [
        { id: "CL-QF-001", chip: "DKXX-CLQ-001", chunk: "JD42-001", title: "Studio open", source: "Studio A · IRD 1", destination: "Pool 2 · Rec 12", workflow: "Export to AVID", date: "2026-04-29", start: "19:30", end: "20:00", duration: "00:30:00", status: "scheduled" },
        { id: "CL-QF-002", chip: "DKXX-CLQ-002", chunk: "JD42-002", title: "Match · Full broadcast", source: "Sat · Astra 19E", destination: "Pool 2 · Rec 12", workflow: "Export to AVID, Storage B", date: "2026-04-29", start: "20:00", end: "22:15", duration: "02:15:00", status: "scheduled" },
        { id: "CL-QF-003", chip: "DKXX-CLQ-003", chunk: "JD42-003", title: "Highlights cut", source: "MAM · Edit 4", destination: "Pool 9 · Rec 02", workflow: "Export to AVID", date: "2026-04-29", start: "22:30", end: "23:15", duration: "00:45:00", status: "draft" },
      ],
    },
    {
      id: "evt-tagesschau",
      title: "Tagesschau · Evening Block",
      color: "oklch(0.72 0.12 50)",
      icon: "T",
      items: [
        { id: "TS-EV-001", chip: "DKXX-TSE-001", chunk: "JD43-001", title: "News feed · DPA", source: "Fiber · DPA-3", destination: "Pool 4 · Rec 18", workflow: "Export to AVID", date: "2026-04-29", start: "17:00", end: "19:30", duration: "02:30:00", status: "live" },
        { id: "TS-EV-002", chip: "DKXX-TSE-002", chunk: "JD43-002", title: "Reuters world feed", source: "Fiber · Reuters-1", destination: "Pool 4 · Rec 18", workflow: "Export to AVID, Storage A", date: "2026-04-29", start: "17:30", end: "20:00", duration: "02:30:00", status: "scheduled" },
        { id: "TS-EV-003", chip: "DKXX-TSE-003", chunk: "JD43-003", title: "Studio package", source: "Studio B · IRD 5", destination: "Pool 4 · Rec 19", workflow: "Export to AVID", date: "2026-04-29", start: "19:45", end: "20:15", duration: "00:30:00", status: "scheduled" },
      ],
    },
    {
      id: "evt-weekend",
      title: "Weekend Sport · Compilation",
      color: "oklch(0.72 0.12 145)",
      icon: "W",
      items: [
        { id: "WK-SP-001", chip: "DKXX-WKS-001", chunk: "JD44-001", title: "Tennis · ATP Munich", source: "Sat · Hotbird 13", destination: "Pool 6 · Rec 22", workflow: "Export to AVID", date: "2026-04-30", start: "10:00", end: "13:30", duration: "03:30:00", status: "scheduled" },
        { id: "WK-SP-002", chip: "DKXX-WKS-002", chunk: "JD44-002", title: "Cycling · Spring Classic", source: "Sat · Eutelsat 9B", destination: "Pool 6 · Rec 23", workflow: "Export to AVID", date: "2026-04-30", start: "13:00", end: "16:45", duration: "03:45:00", status: "scheduled" },
        { id: "WK-SP-003", chip: "DKXX-WKS-003", chunk: "JD44-003", title: "Motorsport · DTM Practice", source: "Cam 4 · IRD 7", destination: "Pool 6 · Rec 24", workflow: "Export to AVID, Storage C", date: "2026-04-30", start: "14:30", end: "16:00", duration: "01:30:00", status: "draft" },
      ],
    },
  ];

  const sources = ["Sat · Eutelsat 9B", "Sat · Astra 19E", "Sat · Hotbird 13", "Cam 1 · IRD 2", "Cam 2 · IRD 3", "Cam 4 · IRD 7", "Studio A · IRD 1", "Studio B · IRD 5", "Fiber · DPA-3", "Fiber · Reuters-1", "MAM · Edit 4"];
  const destinations = ["Pool 1 · Rec 04", "Pool 2 · Rec 12", "Pool 4 · Rec 18", "Pool 4 · Rec 19", "Pool 6 · Rec 22", "Pool 6 · Rec 23", "Pool 6 · Rec 24", "Pool 7 · Rec 56", "Pool 9 · Rec 02"];
  const workflows = ["Export to AVID", "Export to AVID, Storage A", "Export to AVID, Storage B", "Export to AVID, Storage C", "Archive only"];

  return { events, sources, destinations, workflows };
})();
