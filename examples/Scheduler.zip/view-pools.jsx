// VIEW 4 — POOLS × DEVICES TIMELINE
// Pools as collapsible groups; each pool has multiple device lanes;
// item bars span time with status colors. 24h ruler with playhead.

const PoolsView = () => {
  const HOUR_START = 0;
  const HOUR_END = 24;
  const HOURS = HOUR_END - HOUR_START;
  const PX_PER_HOUR = 70;
  const PLAYHEAD_HOUR = 8.0;

  // Status palette — neutral for done, accent for active, warm for record
  const statusColor = {
    complete:  { bg: "oklch(0.32 0.012 240)", border: "oklch(0.40 0.015 240)", text: "var(--fg-1)" },
    running:   { bg: "oklch(0.74 0.12 210 / 0.30)", border: "var(--accent)",   text: "var(--fg-0)" },
    recording: { bg: "oklch(0.74 0.12 25 / 0.32)",  border: "oklch(0.74 0.12 25)", text: "var(--fg-0)", live: true },
    planned:   { bg: "oklch(0.26 0.010 240)", border: "oklch(0.36 0.012 240)", text: "var(--fg-1)" },
    scheduled: { bg: "oklch(0.32 0.018 145)", border: "oklch(0.62 0.10 145)",  text: "var(--fg-0)" },
  };

  // Mock pools, devices, items
  const pools = React.useMemo(() => buildPoolData(), []);
  const [collapsed, setCollapsed] = React.useState({});
  const [hoverItem, setHoverItem] = React.useState(null);

  return (
    <div style={pvStyles.root}>
      <Sidebar active="pools" />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        <header style={pvStyles.topbar}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div>
              <div style={{ fontSize: 11, color: "var(--fg-3)", textTransform: "uppercase", letterSpacing: 0.5 }}>Pools · Recording capacity</div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Mon 24 May 2026 · 00:00–24:00</div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <button className="btn" style={{ fontSize: 12 }}>↺ Zurücksetzen</button>
              <button className="btn" style={{ fontSize: 12 }}>▤ Zu Datum springen</button>
              <button className="btn" style={{ fontSize: 12 }}>◷ Zu Zeit springen</button>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <button className="btn ghost" style={{ fontSize: 12 }}>Filter ▾</button>
            <button className="btn ghost" style={{ fontSize: 12 }}>Einstellungen ⚙</button>
          </div>
        </header>

        {/* Sub-bar */}
        <div style={pvStyles.subbar}>
          <div style={pvStyles.tabs}>
            <span style={{ ...pvStyles.tab, ...pvStyles.tabActive }}>Pool</span>
            <span style={pvStyles.tab}>Device</span>
            <span style={pvStyles.tab}>Workflow</span>
          </div>
          <div style={{ flex: 1 }} />
          <select className="select" style={{ width: 240, fontSize: 12 }}>
            <option>Select quick recording…</option>
            <option>Bundesliga · MD32</option>
            <option>Champions · QF</option>
          </select>
        </div>

        {/* Hour ruler */}
        <div style={pvStyles.rulerWrap}>
          <div style={pvStyles.deviceCol}> </div>
          <div style={{ position: "relative", flex: 1, overflow: "hidden", height: 28 }}>
            {Array.from({ length: HOURS * 4 }).map((_, i) => {
              const isHour = i % 4 === 0;
              return (
                <div key={i} style={{
                  position: "absolute",
                  left: (i / 4) * PX_PER_HOUR,
                  top: isHour ? 0 : 14,
                  bottom: 0,
                  width: 1,
                  background: isHour ? "var(--border-1)" : "var(--border-0)",
                  opacity: isHour ? 1 : 0.7,
                }} />
              );
            })}
            {Array.from({ length: HOURS }).map((_, i) => (
              <div key={i} className="mono" style={{
                position: "absolute",
                left: i * PX_PER_HOUR + 4,
                top: 4,
                fontSize: 10,
                color: "var(--fg-3)",
              }}>
                {String(HOUR_START + i).padStart(2,"0")}:00:00
              </div>
            ))}
            {/* playhead in ruler */}
            <div style={{
              position: "absolute",
              left: (PLAYHEAD_HOUR - HOUR_START) * PX_PER_HOUR,
              top: 0, bottom: 0,
              width: 2, background: "var(--accent)",
            }}>
              <div style={{
                position: "absolute", top: -6, left: -5,
                width: 12, height: 12, borderRadius: 999,
                background: "var(--accent)",
              }} />
            </div>
          </div>
        </div>

        {/* Pools */}
        <div style={{ flex: 1, overflow: "auto", position: "relative" }}>
          {pools.map((pool) => (
            <div key={pool.id}>
              <div
                style={pvStyles.poolHeader}
                onClick={() => setCollapsed(c => ({ ...c, [pool.id]: !c[pool.id] }))}
              >
                <span style={{ display: "inline-block", width: 12, color: "var(--fg-2)", fontSize: 9, transform: collapsed[pool.id] ? "rotate(-90deg)" : "none" }}>▼</span>
                <span style={{ fontSize: 11, fontWeight: 600, color: "var(--fg-1)", textTransform: "uppercase", letterSpacing: 0.5 }}>{pool.name}</span>
                {pool.subtitle && (
                  <span style={{ color: "var(--fg-3)", fontSize: 11, fontWeight: 400, textTransform: "none", letterSpacing: 0 }}>· {pool.subtitle}</span>
                )}
                <div style={{ flex: 1 }} />
                <span style={{ fontSize: 10.5, color: "var(--fg-3)" }} className="mono">{pool.devices.length} devices</span>
                <CapacityBar percent={pool.capacity} />
              </div>
              {!collapsed[pool.id] && pool.devices.map((dev) => (
                <div key={dev.id} style={pvStyles.deviceRow}>
                  <div style={pvStyles.deviceCol}>
                    <span style={{ width: 6, height: 6, borderRadius: 999, background: dev.online ? "oklch(0.72 0.12 145)" : "var(--fg-3)" }} />
                    <span style={{ fontSize: 11.5, color: "var(--fg-1)" }}>{dev.name}</span>
                  </div>
                  <div style={pvStyles.lane}>
                    {/* hour ticks */}
                    {Array.from({ length: HOURS }).map((_, i) => (
                      <div key={i} style={{ position: "absolute", left: i * PX_PER_HOUR, top: 0, bottom: 0, width: 1, background: "var(--border-0)", opacity: 0.4 }} />
                    ))}
                    {/* playhead */}
                    <div style={{ position: "absolute", left: (PLAYHEAD_HOUR - HOUR_START) * PX_PER_HOUR, top: 0, bottom: 0, width: 1, background: "var(--accent)", opacity: 0.6, zIndex: 5 }} />
                    {/* items */}
                    {dev.items.map((it, idx) => {
                      const left = (it.startH - HOUR_START) * PX_PER_HOUR;
                      const width = (it.endH - it.startH) * PX_PER_HOUR;
                      const s = statusColor[it.status];
                      const isHover = hoverItem === `${dev.id}-${idx}`;
                      return (
                        <div
                          key={idx}
                          onMouseEnter={() => setHoverItem(`${dev.id}-${idx}`)}
                          onMouseLeave={() => setHoverItem(null)}
                          style={{
                            position: "absolute",
                            left: left + 1, width: width - 2,
                            top: 3, bottom: 3,
                            background: s.bg,
                            border: `1px solid ${s.border}`,
                            borderLeft: `2px solid ${s.border}`,
                            borderRadius: 3,
                            padding: "0 6px",
                            display: "flex", alignItems: "center", gap: 5,
                            color: s.text, fontSize: 10.5, fontWeight: 500,
                            overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis",
                            cursor: "pointer",
                            zIndex: isHover ? 10 : 1,
                            boxShadow: isHover ? `0 4px 14px oklch(0 0 0 / 0.5), 0 0 0 1px ${s.border}` : "none",
                          }}
                          title={`${it.label} · ${formatHour(it.startH)} – ${formatHour(it.endH)}`}
                        >
                          {s.live && <span style={{ width: 5, height: 5, borderRadius: 999, background: "oklch(0.74 0.12 25)", boxShadow: "0 0 0 3px oklch(0.74 0.12 25 / 0.25)", flex: "0 0 5px" }} />}
                          {it.linked && <span style={{ color: "var(--fg-2)", flex: "0 0 auto" }}>∞</span>}
                          <span style={{ overflow: "hidden", textOverflow: "ellipsis" }}>EINTRAG: {it.label}</span>
                          {isHover && width > 110 && (
                            <span className="mono" style={{ color: "var(--fg-2)", fontSize: 9.5, marginLeft: "auto" }}>
                              {formatHour(it.startH)}
                            </span>
                          )}
                        </div>
                      );
                    })}
                    {/* hover tooltip floating */}
                    {dev.items.map((it, idx) => {
                      if (hoverItem !== `${dev.id}-${idx}`) return null;
                      const left = (it.startH - HOUR_START) * PX_PER_HOUR;
                      const width = (it.endH - it.startH) * PX_PER_HOUR;
                      return (
                        <div key={`tip-${idx}`} style={{
                          position: "absolute",
                          left: left + width + 4, top: -6,
                          background: "var(--bg-2)",
                          border: "1px solid var(--border-1)",
                          borderRadius: 5,
                          padding: "5px 8px",
                          fontSize: 10.5,
                          zIndex: 50,
                          pointerEvents: "none",
                          boxShadow: "0 8px 24px oklch(0 0 0 / 0.4)",
                          minWidth: 140,
                        }}>
                          <div className="mono" style={{ color: "var(--fg-1)" }}>End: {formatHour(it.endH)} · {fmtDur(it.endH - it.startH)}</div>
                          <div style={{ color: "var(--fg-3)", fontSize: 10, marginTop: 2 }}>{it.label}</div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Footer */}
        <footer style={pvStyles.footer}>
          <span style={{ color: "var(--fg-3)", fontSize: 11 }}>© Scheduler · Ingest-Operations</span>
          <div style={{ flex: 1 }} />
          <button className="btn" style={{ fontSize: 12 }}>＋ Create booking</button>
          <button className="btn ghost" style={{ fontSize: 12 }}>✉ Messages <span style={{ background: "var(--accent)", color: "var(--bg-0)", borderRadius: 999, padding: "0 5px", fontSize: 10, marginLeft: 4 }}>3</span></button>
          <span className="mono" style={{ color: "var(--fg-2)", fontSize: 11, marginLeft: 12 }}>Mo 24.05.26 · 08:00:00</span>
        </footer>
      </div>
    </div>
  );
};

const CapacityBar = ({ percent }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
    <div style={{ width: 100, height: 4, background: "var(--bg-3)", borderRadius: 999, overflow: "hidden" }}>
      <div style={{ width: `${percent}%`, height: "100%", background: percent > 80 ? "oklch(0.78 0.12 25)" : "var(--accent)" }} />
    </div>
    <span className="mono" style={{ fontSize: 10.5, color: "var(--fg-2)", width: 30 }}>{percent}%</span>
  </div>
);

const formatHour = (h) => {
  const mm = Math.round((h % 1) * 60);
  return `${String(Math.floor(h)).padStart(2,"0")}:${String(mm).padStart(2,"0")}`;
};
const fmtDur = (h) => {
  const mins = Math.round(h * 60);
  return `${String(Math.floor(mins/60)).padStart(2,"0")}:${String(mins%60).padStart(2,"0")}:00`;
};

// Build deterministic mock data per pool/device
function buildPoolData() {
  const seq = (...specs) => specs.map(([startH, endH, status, label, linked]) => ({ startH, endH, status, label: label || statusLabel(status), linked }));
  const statusLabel = (s) => ({ complete: "Complete", running: "Running", recording: "Recording", planned: "Planned", scheduled: "Scheduled" })[s];

  return [
    {
      id: "p1", name: "Pool 1", subtitle: "Live-Sport, Nachrichten und Studio-Aufnahmen", capacity: 78,
      devices: [
        { id: "p1d1", name: "Gerät 1", online: true, items: seq([0, 2.5, "complete"], [2.5, 5, "complete"], [6, 7.5, "recording", "Aufnahme..."], [7.5, 12, "planned"], [13, 19, "planned"]) },
        { id: "p1dx", name: "GerätXY", online: true, items: seq([0, 2.5, "complete"], [2.5, 5, "complete"], [5, 7.5, "running"], [8, 11, "planned"], [12, 13.5, "recording", "Aufnahme", true], [13.5, 18, "planned"], [18, 23, "planned"]) },
        { id: "p1d2", name: "Gerät 2", online: true, items: seq([0, 2.5, "complete"], [3, 5.5, "complete", "Abgeschlossen", true], [5.5, 8, "complete", "Abgeschlossen", true], [8, 12, "running"], [12, 18, "planned"], [18, 22, "planned"]) },
        { id: "p1d2b",name: "Gerät 2", online: true, items: seq([0, 2.5, "complete"], [2.5, 5, "complete"], [5, 7.5, "complete"], [8, 11, "running"], [12, 18, "planned"], [18, 22, "planned"]) },
        { id: "p1d3", name: "Gerät 3", online: true, items: seq([0, 3, "complete"], [3, 6, "complete"], [6, 9, "running"], [10, 14, "planned"], [14, 18, "planned"], [18, 21, "scheduled"], [21, 23, "planned"]) },
        { id: "p1d3b",name: "Gerät 3", online: true, items: seq([0, 3, "complete"], [3, 6, "complete"], [6, 9, "recording"], [10, 14, "planned"], [14, 18, "planned"], [18, 22, "planned"]) },
        { id: "p1d4", name: "Gerät 4", online: false, items: seq([0, 2.5, "complete"], [4, 6.5, "recording"], [6.5, 11, "planned"], [12, 18, "planned"], [18, 22, "planned"]) },
      ],
    },
    {
      id: "p2", name: "Pool 2", capacity: 64,
      devices: [
        { id: "p2d1", name: "Gerät 1", online: true, items: seq([0, 2.5, "complete"], [2.5, 5, "complete"], [5, 7.5, "complete"], [7.5, 9, "running"], [9, 11, "planned"], [12, 18, "planned"], [18, 22, "planned"]) },
        { id: "p2d2", name: "Gerät 2", online: true, items: seq([0, 2.5, "complete"], [2.5, 5, "complete"], [5, 7.5, "complete"], [7.5, 9, "running"], [9, 12, "planned"], [12, 18, "planned"], [18, 22, "planned"]) },
        { id: "p2d3", name: "Gerät 3", online: true, items: seq([0, 3, "complete"], [3, 5.5, "complete"], [5.5, 8, "complete"], [8, 9.5, "running"], [10, 14, "planned"], [14, 18, "planned"], [18, 22, "planned"]) },
        { id: "p2d4", name: "Gerät 4", online: true, items: seq([0, 3, "complete"], [3, 6, "complete"], [6, 8.5, "complete"], [8.5, 9.5, "running"], [13, 19, "planned"]) },
        { id: "p2d5", name: "Gerät 5", online: true, items: seq([0, 2.5, "complete", "Abgeschlossen", true], [2.5, 5.5, "complete"], [5.5, 8, "complete"], [9, 13, "recording"], [14, 19, "planned"]) },
        { id: "p2d6", name: "Gerät 6", online: true, items: seq([0, 2.5, "complete"], [2.5, 5.5, "complete"], [5.5, 8, "complete"], [8, 11, "planned"], [12, 16, "planned"], [16, 19, "planned"], [19, 22, "planned"]) },
        { id: "p2d7", name: "Gerät 7", online: true, items: seq([0, 3, "complete"], [3, 6, "complete"], [6, 9, "running"], [10, 14, "planned"], [14, 18, "planned"], [18, 22, "planned"]) },
        { id: "p2d8", name: "Gerät 8", online: true, items: seq([0, 3, "complete"], [3, 6, "complete"], [6, 9, "running"], [10, 14, "planned"], [14, 18, "planned"]) },
        { id: "p2d9", name: "Gerät 9", online: true, items: seq([0, 3, "complete"], [3, 6, "complete"], [6, 9, "running"], [10, 13, "planned"], [13, 18, "scheduled"], [18, 22, "planned"]) },
        { id: "p2dt", name: "Gerät 1…", online: true, items: seq([0, 2.5, "complete"], [3, 6, "complete", "Abgeschlossen", true], [6, 9, "running"], [10, 14, "planned"], [14, 18, "planned"], [18, 22, "planned"]) },
      ],
    },
    {
      id: "p3", name: "Pool 3", capacity: 12,
      devices: [],
    },
    {
      id: "p4", name: "Pool 4", capacity: 71,
      devices: [
        { id: "p4d1", name: "Gerät 1", online: true, items: seq([0, 3, "complete"], [3, 6, "complete"], [6, 9, "running"], [10, 14, "planned"], [14, 18, "planned"], [18, 22, "planned"]) },
        { id: "p4d2", name: "Gerät 2", online: true, items: seq([0, 3, "complete"], [3, 6, "complete"], [6, 9, "running"], [10, 14, "planned"], [14, 18, "planned"], [18, 22, "planned"]) },
        { id: "p4d3", name: "Gerät 3", online: true, items: seq([0, 3, "complete"], [3, 6, "complete", "Abgeschlossen", true], [6, 9, "running"], [10, 14, "planned"], [14, 18, "planned"], [18, 22, "planned"]) },
        { id: "p4d4", name: "Gerät 4", online: true, items: seq([0, 3, "complete"], [3, 6, "complete"], [6, 9, "running"], [10, 14, "planned"], [14, 18, "planned"], [18, 22, "planned"]) },
        { id: "p4d5", name: "Gerät 5", online: true, items: seq([0, 3, "complete", "Abgeschlossen", true], [3, 6, "complete"], [6, 9, "complete"], [10, 14, "planned"], [14, 18, "planned"], [18, 22, "planned"]) },
        { id: "p4d6", name: "Gerät 6", online: true, items: seq([0, 3, "complete"], [3, 6, "complete"], [6, 9, "complete"], [10, 14, "planned"]) },
      ],
    },
  ];
}

const pvStyles = {
  root: { display: "flex", height: "100%", background: "var(--bg-0)" },
  topbar: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 16px", borderBottom: "1px solid var(--border-0)", gap: 16 },
  subbar: { display: "flex", alignItems: "center", gap: 8, padding: "6px 14px", borderBottom: "1px solid var(--border-0)", background: "var(--bg-1)" },
  tabs: { display: "flex", gap: 2 },
  tab: { padding: "5px 14px", fontSize: 11.5, color: "var(--fg-2)", borderRadius: 4, fontWeight: 500, textTransform: "uppercase", letterSpacing: 0.5 },
  tabActive: { color: "var(--accent)", borderBottom: "2px solid var(--accent)", borderRadius: 0, paddingBottom: 5 },
  rulerWrap: { display: "flex", borderBottom: "1px solid var(--border-0)", background: "var(--bg-1)" },
  deviceCol: { width: 84, flex: "0 0 84px", padding: "6px 10px", borderRight: "1px solid var(--border-0)", display: "flex", alignItems: "center", gap: 6 },
  poolHeader: { display: "flex", alignItems: "center", gap: 8, padding: "6px 12px", background: "var(--bg-1)", borderBottom: "1px solid var(--border-0)", cursor: "pointer", height: 28 },
  deviceRow: { display: "flex", height: 26, borderBottom: "1px solid oklch(0.20 0.008 240)" },
  lane: { flex: 1, position: "relative", overflow: "hidden", background: "var(--bg-0)" },
  footer: { display: "flex", alignItems: "center", gap: 10, padding: "8px 14px", borderTop: "1px solid var(--border-0)", background: "var(--bg-1)" },
};

Object.assign(window, { PoolsView });
