// VIEW 1 — TABLE VIEW
// Hierarchical groups → items, with editable spec form below.
// Linear/Notion-adjacent: tight rows, no hairline shadows, monospace timecodes.

const TableView = () => {
  const data = window.SCHED_DATA;
  const [collapsed, setCollapsed] = React.useState({});
  const [selected, setSelected] = React.useState(new Set(["BL-32-001", "BL-32-002"]));
  const [activeItem, setActiveItem] = React.useState(data.events[0].items[0]);
  const [tab, setTab] = React.useState("specification");
  const [query, setQuery] = React.useState("");
  const [sortKey, setSortKey] = React.useState("start");

  const toggle = (id) => setCollapsed((c) => ({ ...c, [id]: !c[id] }));
  const toggleSel = (id) => setSelected((s) => {
    const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n;
  });

  const filtered = data.events.map((g) => ({
    ...g,
    items: g.items.filter((it) =>
      !query ||
      it.title.toLowerCase().includes(query.toLowerCase()) ||
      it.id.toLowerCase().includes(query.toLowerCase()) ||
      it.source.toLowerCase().includes(query.toLowerCase())
    ),
  })).filter((g) => g.items.length > 0 || !query);

  return (
    <div style={tvStyles.root}>
      <Sidebar active="schedule" />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        {/* Top bar */}
        <header style={tvStyles.topbar}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button className="btn ghost" style={{ padding: "5px 8px" }}>← Zur Timeline</button>
            <div style={{ width: 1, height: 16, background: "var(--border-0)" }} />
            <div>
              <div style={{ fontSize: 11, color: "var(--fg-3)", textTransform: "uppercase", letterSpacing: 0.5 }}>Booking-Definition</div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Mi 29. Apr · Produktionsblock</div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={tvStyles.viewSwitch}>
              <span style={tvStyles.viewSwitchActive}>Definition</span>
              <span style={tvStyles.viewSwitchInactive}>Komponenten</span>
            </div>
            <button className="btn ghost" style={{ padding: 6 }}>✕</button>
          </div>
        </header>

        {/* Toolbar */}
        <div style={tvStyles.toolbar}>
          <div style={{ position: "relative", width: 280 }}>
            <input
              className="input"
              placeholder="Nach Titel, ID oder Quelle filtern…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              style={{ paddingLeft: 28, fontSize: 12 }}
            />
            <span style={{ position: "absolute", left: 9, top: "50%", transform: "translateY(-50%)", color: "var(--fg-3)", fontSize: 13 }}>⌕</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ color: "var(--fg-2)", fontSize: 12 }}>Gruppieren nach</span>
            <button className="btn" style={{ fontSize: 12 }}>Event ▾</button>
          </div>
          <div style={{ flex: 1 }} />
          <div style={{ color: "var(--fg-2)", fontSize: 12 }}>
            <span style={{ color: "var(--fg-0)", fontWeight: 500 }}>{selected.size}</span> ausgewählt
          </div>
          <button className="btn" style={{ fontSize: 12 }} disabled={!selected.size}>
            <span>⎘</span> Duplizieren
          </button>
          <button className="btn danger" style={{ fontSize: 12 }} disabled={!selected.size}>
            <span>✕</span> Löschen
          </button>
          <div style={{ width: 1, height: 18, background: "var(--border-0)", margin: "0 4px" }} />
          <button className="btn primary" style={{ fontSize: 12 }}>+ Booking hinzufügen</button>
        </div>

        {/* Table */}
        <div style={tvStyles.tableWrap}>
          <div style={tvStyles.tableHeader}>
            <div style={{ ...tvStyles.cell, width: 28, paddingLeft: 14 }}>
              <input type="checkbox" style={{ accentColor: "var(--accent)" }} />
            </div>
            <div style={{ ...tvStyles.cell, flex: "2 1 280px" }}>Titel</div>
            <div style={{ ...tvStyles.cell, width: 90 }}>Startdatum</div>
            <div style={{ ...tvStyles.cell, width: 70 }}>Zeit ↓</div>
            <div style={{ ...tvStyles.cell, width: 80 }}>Dauer</div>
            <div style={{ ...tvStyles.cell, flex: "1 1 160px" }}>Quelle ↓</div>
            <div style={{ ...tvStyles.cell, flex: "1 1 140px" }}>Ziel</div>
            <div style={{ ...tvStyles.cell, flex: "1 1 160px" }}>Workflow</div>
            <div style={{ ...tvStyles.cell, width: 100 }}>Status</div>
            <div style={{ ...tvStyles.cell, width: 70, justifyContent: "flex-end", paddingRight: 14 }}>·</div>
          </div>
          <div style={{ overflow: "auto", flex: 1 }}>
            {filtered.map((grp) => (
              <div key={grp.id}>
                <div style={tvStyles.groupRow} onClick={() => toggle(grp.id)}>
                  <div style={{ ...tvStyles.cell, width: 28, paddingLeft: 14 }}>
                    <span style={{ color: "var(--fg-2)", fontSize: 10, display: "inline-block", transform: collapsed[grp.id] ? "rotate(-90deg)" : "none", transition: "transform 120ms" }}>▼</span>
                  </div>
                  <div style={{ ...tvStyles.cell, flex: "2 1 280px", gap: 10 }}>
                    <span style={{
                      width: 18, height: 18, borderRadius: 4,
                      background: grp.color, opacity: 0.18,
                      border: `1px solid ${grp.color}`,
                      display: "grid", placeItems: "center",
                      fontSize: 10, fontWeight: 700, color: grp.color,
                    }}>{grp.icon}</span>
                    <span style={{ fontWeight: 600 }}>{grp.title}</span>
                    <span style={{ color: "var(--fg-3)", fontSize: 11 }}>{grp.items.length} Einträge</span>
                  </div>
                  <div style={{ ...tvStyles.cell, flex: 1, justifyContent: "flex-end", paddingRight: 14, color: "var(--fg-2)", fontSize: 12 }}>
                    <span>+ Komponente hinzufügen</span>
                  </div>
                </div>
                {!collapsed[grp.id] && grp.items.map((it) => {
                  const isSel = selected.has(it.id);
                  const isActive = activeItem && activeItem.id === it.id;
                  return (
                    <div
                      key={it.id}
                      style={{
                        ...tvStyles.row,
                        ...(isActive ? tvStyles.rowActive : null),
                        ...(isSel && !isActive ? tvStyles.rowSelected : null),
                      }}
                      onClick={() => setActiveItem(it)}
                    >
                      <div style={{ ...tvStyles.cell, width: 28, paddingLeft: 14 }}>
                        <input
                          type="checkbox"
                          checked={isSel}
                          onChange={(e) => { e.stopPropagation(); toggleSel(it.id); }}
                          onClick={(e) => e.stopPropagation()}
                          style={{ accentColor: "var(--accent)" }}
                        />
                      </div>
                      <div style={{ ...tvStyles.cell, flex: "2 1 280px", gap: 8 }}>
                        <span style={{ width: 3, height: 16, borderRadius: 2, background: grp.color, flex: "0 0 3px" }} />
                        <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.title}</span>
                      </div>
                      <div style={{ ...tvStyles.cell, width: 90 }} className="mono">{fmtDate(it.date)}</div>
                      <div style={{ ...tvStyles.cell, width: 70 }} className="mono">{it.start}</div>
                      <div style={{ ...tvStyles.cell, width: 80 }} className="mono" >{it.duration}</div>
                      <div style={{ ...tvStyles.cell, flex: "1 1 160px", color: "var(--fg-1)" }}>{it.source}</div>
                      <div style={{ ...tvStyles.cell, flex: "1 1 140px", color: "var(--fg-1)" }}>{it.destination}</div>
                      <div style={{ ...tvStyles.cell, flex: "1 1 160px", color: "var(--fg-1)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.workflow}</div>
                      <div style={{ ...tvStyles.cell, width: 100 }}>
                        <StatusChip status={it.status} />
                      </div>
                      <div style={{ ...tvStyles.cell, width: 70, justifyContent: "flex-end", paddingRight: 14, gap: 4, color: "var(--fg-3)" }}>
                        <span title="Duplizieren">⎘</span>
                        <span title="Bearbeiten">✎</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        {/* Spec form */}
        <div style={tvStyles.specWrap}>
          <div style={tvStyles.specTabs}>
            {["specification", "metadata"].map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                style={{ ...tvStyles.tab, ...(tab === t ? tvStyles.tabActive : null) }}
              >
                {t === "specification" ? "Spezifikation" : "Metadaten"}
              </button>
            ))}
            <div style={{ flex: 1 }} />
            {activeItem && (
              <div style={{ display: "flex", alignItems: "center", gap: 8, color: "var(--fg-2)", fontSize: 12 }}>
                <span>Bearbeite</span>
                <span className="mono" style={{ color: "var(--fg-0)" }}>{activeItem.id}</span>
              </div>
            )}
          </div>
          {activeItem && tab === "specification" && (
            <SpecForm item={activeItem} />
          )}
          {activeItem && tab === "metadata" && <MetadataForm item={activeItem} />}
          <div style={tvStyles.specFooter}>
            <span style={{ color: "var(--fg-3)", fontSize: 11 }}>Zuletzt bearbeitet vor 2 Min. von Jana M.</span>
            <div style={{ flex: 1 }} />
            <button className="btn">Abbrechen</button>
            <button className="btn primary">Speichern</button>
          </div>
        </div>
      </div>
    </div>
  );
};

const SpecForm = ({ item }) => {
  return (
    <div style={specStyles.grid}>
      <Field label="Status">
        <StatusChip status={item.status} />
      </Field>
      <Field label="Item-ID" hint="ⓘ" full>
        <input className="input mono" defaultValue={item.id} />
      </Field>
      <Field label="Chip-ID" hint="ⓘ">
        <input className="input mono" defaultValue={item.chip} />
      </Field>
      <Field label="Chunk-ID" hint="ⓘ">
        <input className="input mono" defaultValue={item.chunk} />
      </Field>
      <Field label="Startdatum" required>
        <div style={specStyles.iconInput}>
          <input className="input mono" defaultValue={fmtDate(item.date)} />
          <span style={specStyles.fieldIcon}>▤</span>
        </div>
      </Field>
      <Field label="Startzeit" required>
        <div style={specStyles.iconInput}>
          <input className="input mono" defaultValue={item.start} />
          <span style={specStyles.fieldIcon}>◷</span>
        </div>
      </Field>
      <Field label="Dauer" required>
        <input className="input mono" defaultValue={item.duration} placeholder="HH:MM:SS" />
      </Field>
      <Field label="Enddatum" required>
        <div style={specStyles.iconInput}>
          <input className="input mono" defaultValue={fmtDate(item.date)} />
          <span style={specStyles.fieldIcon}>▤</span>
        </div>
      </Field>
      <Field label="Endzeit" required>
        <div style={specStyles.iconInput}>
          <input className="input mono" defaultValue={item.end} />
          <span style={specStyles.fieldIcon}>◷</span>
        </div>
      </Field>
    </div>
  );
};

const MetadataForm = ({ item }) => {
  const meta = [
    ["Erstellt", "2026-04-22 09:14"],
    ["Geändert", "2026-04-29 11:42"],
    ["Verantwortlich", "Jana Müller"],
    ["Tags", "sport, wochenende, livefeed"],
    ["Geschätzte Bitrate", "50 Mb/s"],
    ["Codec", "XAVC Intra · 4:2:2 10-bit"],
    ["Audio", "8 Kanäle · 48 kHz"],
    ["Notizen", "Satelliten-Übergabe bis 11:30 bestätigen. Backup-Feed verfügbar auf Eutelsat 9B Tx-3."],
  ];
  return (
    <div style={specStyles.metaGrid}>
      {meta.map(([k, v]) => (
        <div key={k} style={specStyles.metaRow}>
          <div style={{ color: "var(--fg-2)", fontSize: 12, width: 160, flex: "0 0 160px" }}>{k}</div>
          <div style={{ color: "var(--fg-0)", fontSize: 13 }}>{v}</div>
        </div>
      ))}
    </div>
  );
};

const Field = ({ label, hint, required, full, children }) => (
  <div style={{ ...specStyles.field, ...(full ? { gridColumn: "span 2" } : null) }}>
    <label style={specStyles.label}>
      {label}
      {required && <span style={{ color: "oklch(0.78 0.12 25)", marginLeft: 2 }}>*</span>}
      {hint && <span style={{ color: "var(--fg-3)", marginLeft: 4 }}>{hint}</span>}
    </label>
    {children}
  </div>
);

const fmtDate = (iso) => {
  const [y, m, d] = iso.split("-");
  return `${d}.${m}.${y}`;
};

const tvStyles = {
  root: { display: "flex", height: "100%", background: "var(--bg-0)" },
  topbar: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    padding: "10px 16px", borderBottom: "1px solid var(--border-0)",
    background: "var(--bg-0)",
  },
  viewSwitch: {
    display: "flex", padding: 2, borderRadius: 999,
    background: "var(--bg-2)", border: "1px solid var(--border-0)",
    fontSize: 12,
  },
  viewSwitchActive: {
    padding: "4px 12px", borderRadius: 999,
    background: "var(--bg-4)", color: "var(--fg-0)", fontWeight: 500,
  },
  viewSwitchInactive: { padding: "4px 12px", color: "var(--fg-2)" },
  toolbar: {
    display: "flex", alignItems: "center", gap: 10,
    padding: "8px 14px", borderBottom: "1px solid var(--border-0)",
    background: "var(--bg-0)",
  },
  tableWrap: {
    flex: 1, minHeight: 0, display: "flex", flexDirection: "column",
    background: "var(--bg-0)",
  },
  tableHeader: {
    display: "flex", alignItems: "center",
    background: "var(--bg-1)",
    borderBottom: "1px solid var(--border-0)",
    color: "var(--fg-2)", fontSize: 11, fontWeight: 500,
    textTransform: "uppercase", letterSpacing: 0.5,
    height: 32, flex: "0 0 32px",
  },
  cell: {
    padding: "0 8px", display: "flex", alignItems: "center", gap: 6,
    overflow: "hidden", whiteSpace: "nowrap",
  },
  groupRow: {
    display: "flex", alignItems: "center",
    height: 36, flex: "0 0 36px",
    background: "var(--bg-1)",
    borderBottom: "1px solid var(--border-0)",
    cursor: "pointer", color: "var(--fg-0)",
  },
  row: {
    display: "flex", alignItems: "center",
    height: 34, flex: "0 0 34px",
    borderBottom: "1px solid oklch(0.22 0.008 240)",
    cursor: "pointer", color: "var(--fg-0)", fontSize: 12.5,
  },
  rowActive: {
    background: "oklch(0.74 0.12 210 / 0.10)",
    boxShadow: "inset 2px 0 0 var(--accent)",
  },
  rowSelected: {
    background: "var(--bg-2)",
  },
  specWrap: {
    flex: "0 0 auto",
    borderTop: "1px solid var(--border-0)",
    background: "var(--bg-1)",
    display: "flex", flexDirection: "column",
  },
  specTabs: {
    display: "flex", alignItems: "center", gap: 2,
    padding: "0 14px",
    borderBottom: "1px solid var(--border-0)",
    background: "var(--bg-0)",
  },
  tab: {
    padding: "10px 14px", border: "none", background: "transparent",
    color: "var(--fg-2)", fontSize: 12, fontWeight: 500, cursor: "pointer",
    borderBottom: "2px solid transparent", marginBottom: -1,
  },
  tabActive: {
    color: "var(--fg-0)", borderBottomColor: "var(--accent)",
  },
  specFooter: {
    display: "flex", alignItems: "center", gap: 8,
    padding: "10px 14px",
    borderTop: "1px solid var(--border-0)",
    background: "var(--bg-1)",
  },
};

const specStyles = {
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(5, 1fr)",
    gap: "14px 18px",
    padding: "16px 14px",
  },
  field: { display: "flex", flexDirection: "column", gap: 5, minWidth: 0 },
  label: {
    fontSize: 11, color: "var(--fg-2)",
    textTransform: "uppercase", letterSpacing: 0.4, fontWeight: 500,
  },
  iconInput: { position: "relative" },
  fieldIcon: {
    position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)",
    color: "var(--fg-3)", fontSize: 13, pointerEvents: "none",
  },
  metaGrid: { padding: "16px 14px", display: "flex", flexDirection: "column", gap: 8 },
  metaRow: { display: "flex", alignItems: "flex-start", gap: 14, paddingBottom: 8, borderBottom: "1px solid var(--border-0)" },
};

Object.assign(window, { TableView });
