// Shared chrome: app sidebar, top bar, status pills, etc.
// All artboards reuse these for visual coherence.

const Sidebar = ({ active = "schedule" }) => {
  const items = [
    { id: "timeline", label: "Timeline", icon: "▦" },
    { id: "schedule", label: "Schedule", icon: "≡" },
    { id: "pools", label: "Pools", icon: "◫" },
    { id: "sources", label: "Sources", icon: "◉" },
    { id: "workflows", label: "Workflows", icon: "→" },
    { id: "archive", label: "Archive", icon: "◰" },
  ];
  return (
    <aside style={sidebarStyles.root}>
      <div style={sidebarStyles.brand}>
        <div style={sidebarStyles.mark}>S</div>
        <div>
          <div style={{ fontWeight: 600, fontSize: 13 }}>Scheduler</div>
          <div style={{ color: "var(--fg-3)", fontSize: 11 }}>RTL · Ingest Ops</div>
        </div>
      </div>
      <nav style={{ display: "flex", flexDirection: "column", gap: 1, padding: "8px" }}>
        {items.map((it) => (
          <div key={it.id} style={{
            ...sidebarStyles.item,
            ...(active === it.id ? sidebarStyles.itemActive : null),
          }}>
            <span style={{ width: 16, color: "var(--fg-2)", fontSize: 13, textAlign: "center" }}>{it.icon}</span>
            <span>{it.label}</span>
          </div>
        ))}
      </nav>
      <div style={{ flex: 1 }} />
      <div style={{ padding: 12, borderTop: "1px solid var(--border-0)", display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{ width: 24, height: 24, borderRadius: 999, background: "oklch(0.74 0.12 25)", display: "grid", placeItems: "center", color: "oklch(0.18 0.008 240)", fontSize: 11, fontWeight: 600 }}>JM</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>Jana Müller</div>
          <div style={{ fontSize: 11, color: "var(--fg-3)" }}>Ops Lead</div>
        </div>
      </div>
    </aside>
  );
};

const sidebarStyles = {
  root: {
    width: 200, flex: "0 0 200px",
    background: "var(--bg-1)",
    borderRight: "1px solid var(--border-0)",
    display: "flex", flexDirection: "column",
  },
  brand: {
    display: "flex", alignItems: "center", gap: 10,
    padding: "14px 14px 12px", borderBottom: "1px solid var(--border-0)",
  },
  mark: {
    width: 28, height: 28, borderRadius: 7,
    background: "linear-gradient(135deg, var(--accent), oklch(0.62 0.12 210))",
    display: "grid", placeItems: "center",
    color: "oklch(0.18 0.008 240)", fontWeight: 700, fontSize: 14,
  },
  item: {
    display: "flex", alignItems: "center", gap: 10,
    padding: "6px 10px", borderRadius: 5,
    color: "var(--fg-1)", fontSize: 13,
    cursor: "default",
  },
  itemActive: {
    background: "var(--bg-3)", color: "var(--fg-0)", fontWeight: 500,
  },
};

// Status chip for booking items
const StatusChip = ({ status }) => {
  const map = {
    live:      { label: "Live",      cls: "live" },
    scheduled: { label: "Scheduled", cls: "scheduled" },
    draft:     { label: "Draft",     cls: "draft" },
    planned:   { label: "Planned",   cls: "scheduled" },
  };
  const v = map[status] || { label: status, cls: "draft" };
  return (
    <span className={`chip ${v.cls}`}>
      <span className="dot" />
      {v.label}
    </span>
  );
};

// Tiny iconography (pure unicode for restraint)
const Icon = ({ ch, size = 13, color = "currentColor" }) => (
  <span style={{ display: "inline-block", fontSize: size, color, lineHeight: 1 }}>{ch}</span>
);

Object.assign(window, { Sidebar, StatusChip, Icon });
