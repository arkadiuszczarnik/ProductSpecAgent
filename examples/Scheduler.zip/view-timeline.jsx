// VIEW 2 — TIMELINE / GANTT VIEW
// Items laid out across a 24h ruler, drag to reschedule, snap to 15min.

const TimelineView = () => {
  const data = window.SCHED_DATA;
  const today = "2026-04-29";
  const todayEvents = data.events
    .map(g => ({ ...g, items: g.items.filter(i => i.date === today) }))
    .filter(g => g.items.length);

  // Hours shown
  const HOUR_START = 10;
  const HOUR_END = 24;
  const HOURS = HOUR_END - HOUR_START;
  const PX_PER_HOUR = 88;
  const SNAP_MIN = 15;

  const [items, setItems] = React.useState(() => {
    const out = [];
    todayEvents.forEach((g) => g.items.forEach((it) => {
      out.push({ ...it, color: g.color, group: g.title, groupId: g.id, icon: g.icon });
    }));
    return out;
  });
  const [activeId, setActiveId] = React.useState(items[0]?.id);
  const [now] = React.useState(13.4); // hours
  const [filter, setFilter] = React.useState("");

  const toMin = (hhmm) => {
    const [h, m] = hhmm.split(":").map(Number); return h * 60 + m;
  };
  const toHHMM = (min) => {
    const h = Math.floor(min / 60), m = min % 60;
    return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
  };
  const startPx = (it) => ((toMin(it.start) - HOUR_START * 60) / 60) * PX_PER_HOUR;
  const widthPx = (it) => ((toMin(it.end) - toMin(it.start)) / 60) * PX_PER_HOUR;

  const onDragStart = (e, id) => {
    const it = items.find(i => i.id === id);
    e.dataTransfer.setData("text/plain", JSON.stringify({ id, offsetX: e.nativeEvent.offsetX, durationMin: toMin(it.end) - toMin(it.start) }));
    e.dataTransfer.effectAllowed = "move";
    setActiveId(id);
  };
  const onDrop = (e, lane) => {
    e.preventDefault();
    const { id, offsetX, durationMin } = JSON.parse(e.dataTransfer.getData("text/plain"));
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left - offsetX;
    let startMinFromZero = (x / PX_PER_HOUR) * 60 + HOUR_START * 60;
    startMinFromZero = Math.max(HOUR_START * 60, Math.round(startMinFromZero / SNAP_MIN) * SNAP_MIN);
    const endMin = startMinFromZero + durationMin;
    setItems(arr => arr.map(it => it.id === id ? { ...it, start: toHHMM(startMinFromZero), end: toHHMM(endMin) } : it));
  };

  const lanes = todayEvents.map(g => ({ id: g.id, title: g.title, color: g.color, icon: g.icon }));
  const activeItem = items.find(i => i.id === activeId);

  return (
    <div style={tlStyles.root}>
      <Sidebar active="timeline" />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        {/* Top bar */}
        <header style={tlStyles.topbar}>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div>
              <div style={{ fontSize: 11, color: "var(--fg-3)", textTransform: "uppercase", letterSpacing: 0.5 }}>Timeline · Sendetag</div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Mi 29. Apr 2026</div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <button className="btn ghost" style={{ padding: "4px 8px" }}>‹</button>
              <button className="btn" style={{ fontSize: 12 }}>Heute</button>
              <button className="btn ghost" style={{ padding: "4px 8px" }}>›</button>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={tlStyles.zoom}>
              <span style={tlStyles.zoomBtn}>Day</span>
              <span style={{ ...tlStyles.zoomBtn, ...tlStyles.zoomActive }}>Hours</span>
              <span style={tlStyles.zoomBtn}>15min</span>
            </div>
            <button className="btn primary" style={{ fontSize: 12 }}>+ Neue Buchung</button>
          </div>
        </header>

        {/* Toolbar */}
        <div style={tlStyles.toolbar}>
          <div style={{ position: "relative", width: 240 }}>
            <input className="input" placeholder="Buchungen durchsuchen…" value={filter} onChange={e => setFilter(e.target.value)} style={{ paddingLeft: 28, fontSize: 12 }} />
            <span style={{ position: "absolute", left: 9, top: "50%", transform: "translateY(-50%)", color: "var(--fg-3)" }}>⌕</span>
          </div>
          <button className="btn" style={{ fontSize: 12 }}>Alle Quellen ▾</button>
          <button className="btn" style={{ fontSize: 12 }}>Alle Pools ▾</button>
          <div style={{ flex: 1 }} />
          <Legend />
          <span className="kbd">Zum Verschieben ziehen</span>
        </div>

        {/* Timeline grid */}
        <div style={{ flex: 1, display: "flex", minHeight: 0 }}>
          <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
            {/* Hour ruler */}
            <div style={tlStyles.rulerRow}>
              <div style={tlStyles.laneLabel}> </div>
              <div style={{ position: "relative", display: "flex", flex: 1, overflow: "hidden" }}>
                {Array.from({ length: HOURS }).map((_, i) => (
                  <div key={i} style={{ width: PX_PER_HOUR, flex: `0 0 ${PX_PER_HOUR}px`, padding: "8px 8px", borderLeft: "1px solid var(--border-0)", color: "var(--fg-2)", fontSize: 11 }} className="mono">
                    {String(HOUR_START + i).padStart(2,"0")}:00
                  </div>
                ))}
              </div>
            </div>

            {/* Lanes */}
            <div style={{ flex: 1, overflowY: "auto", overflowX: "auto" }}>
              {lanes.map((lane) => {
                const laneItems = items.filter(i => i.groupId === lane.id);
                return (
                  <div key={lane.id} style={tlStyles.laneRow}>
                    <div style={tlStyles.laneLabel}>
                      <span style={{ width: 18, height: 18, borderRadius: 4, background: lane.color, opacity: 0.18, border: `1px solid ${lane.color}`, display: "grid", placeItems: "center", fontSize: 10, fontWeight: 700, color: lane.color }}>{lane.icon}</span>
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 12, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{lane.title}</div>
                        <div style={{ fontSize: 11, color: "var(--fg-3)" }}>{laneItems.length} Buchungen</div>
                      </div>
                    </div>
                    <div
                      style={tlStyles.laneCanvas}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={(e) => onDrop(e, lane)}
                    >
                      {/* hour grid */}
                      {Array.from({ length: HOURS }).map((_, i) => (
                        <div key={i} style={{ position: "absolute", left: i * PX_PER_HOUR, top: 0, bottom: 0, width: 1, background: "var(--border-0)", opacity: 0.5 }} />
                      ))}
                      {/* now line */}
                      <div style={{ position: "absolute", left: (now - HOUR_START) * PX_PER_HOUR, top: 0, bottom: 0, width: 1, background: "oklch(0.78 0.12 25)", zIndex: 5 }}>
                        <div style={{ position: "absolute", top: -3, left: -3, width: 7, height: 7, borderRadius: 999, background: "oklch(0.78 0.12 25)" }} />
                      </div>
                      {/* items */}
                      {laneItems.map((it) => {
                        const isActive = activeId === it.id;
                        return (
                          <div
                            key={it.id}
                            draggable
                            onDragStart={(e) => onDragStart(e, it.id)}
                            onClick={() => setActiveId(it.id)}
                            style={{
                              position: "absolute",
                              left: startPx(it), width: widthPx(it),
                              top: 8, bottom: 8,
                              background: `color-mix(in oklch, ${lane.color} 22%, var(--bg-1))`,
                              border: `1px solid ${lane.color}`,
                              borderLeft: `3px solid ${lane.color}`,
                              borderRadius: 5,
                              padding: "5px 8px",
                              cursor: "grab",
                              overflow: "hidden",
                              boxShadow: isActive ? "0 0 0 2px var(--accent), 0 4px 16px oklch(0 0 0 / 0.4)" : "none",
                              zIndex: isActive ? 4 : 2,
                            }}
                          >
                            <div style={{ fontSize: 11.5, fontWeight: 600, color: "var(--fg-0)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.title}</div>
                            <div className="mono" style={{ fontSize: 10.5, color: "var(--fg-1)", marginTop: 1 }}>{it.start}–{it.end}</div>
                            {widthPx(it) > 140 && (
                              <div style={{ fontSize: 10.5, color: "var(--fg-2)", marginTop: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.source} → {it.destination}</div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Detail panel */}
          {activeItem && (
            <aside style={tlStyles.detail}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                <span style={{ width: 22, height: 22, borderRadius: 5, background: activeItem.color, opacity: 0.2, border: `1px solid ${activeItem.color}`, display: "grid", placeItems: "center", fontSize: 11, fontWeight: 700, color: activeItem.color }}>{activeItem.icon}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 11, color: "var(--fg-3)" }}>{activeItem.group}</div>
                  <div style={{ fontWeight: 600, fontSize: 14, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{activeItem.title}</div>
                </div>
                <StatusChip status={activeItem.status} />
              </div>

              <DetailRow label="Item-ID" value={<span className="mono">{activeItem.id}</span>} />
              <DetailRow label="Zeitfenster" value={<span className="mono">{activeItem.start} – {activeItem.end}</span>} />
              <DetailRow label="Dauer" value={<span className="mono">{activeItem.duration}</span>} />
              <div style={{ height: 12 }} />
              <div style={{ fontSize: 11, color: "var(--fg-2)", textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 8 }}>Routing</div>
              <DetailRow label="Quelle" value={activeItem.source} />
              <DetailRow label="Ziel" value={activeItem.destination} />
              <DetailRow label="Workflow" value={activeItem.workflow} />

              <div style={{ display: "flex", gap: 6, marginTop: 14 }}>
                <button className="btn" style={{ flex: 1, justifyContent: "center" }}>Open</button>
                <button className="btn primary" style={{ flex: 1, justifyContent: "center" }}>Edit</button>
              </div>

              <div style={{ marginTop: 16, padding: 10, background: "var(--bg-2)", borderRadius: 6, fontSize: 11.5, color: "var(--fg-2)", lineHeight: 1.5 }}>
                <div style={{ color: "var(--fg-1)", fontWeight: 500, marginBottom: 4 }}>⚐ Konfliktprüfung</div>
                Keine Überschneidung auf {activeItem.destination}.<br />
                Auslastung bei <span className="mono" style={{ color: "var(--fg-0)" }}>72%</span> in diesem Zeitfenster.
              </div>
            </aside>
          )}
        </div>
      </div>
    </div>
  );
};

const Legend = () => (
  <div style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 11, color: "var(--fg-2)" }}>
    <span style={{ display: "flex", alignItems: "center", gap: 5 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: "var(--accent)" }} /> Bundesliga</span>
    <span style={{ display: "flex", alignItems: "center", gap: 5 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: "oklch(0.72 0.12 290)" }} /> Champions</span>
    <span style={{ display: "flex", alignItems: "center", gap: 5 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: "oklch(0.72 0.12 50)" }} /> Tagesschau</span>
  </div>
);

const DetailRow = ({ label, value }) => (
  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "5px 0", borderBottom: "1px solid var(--border-0)", fontSize: 12 }}>
    <span style={{ color: "var(--fg-2)" }}>{label}</span>
    <span style={{ color: "var(--fg-0)", textAlign: "right", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{value}</span>
  </div>
);

const tlStyles = {
  root: { display: "flex", height: "100%", background: "var(--bg-0)" },
  topbar: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 16px", borderBottom: "1px solid var(--border-0)" },
  zoom: { display: "flex", padding: 2, borderRadius: 6, background: "var(--bg-2)", border: "1px solid var(--border-0)", fontSize: 11.5 },
  zoomBtn: { padding: "3px 10px", borderRadius: 4, color: "var(--fg-2)" },
  zoomActive: { background: "var(--bg-4)", color: "var(--fg-0)", fontWeight: 500 },
  toolbar: { display: "flex", alignItems: "center", gap: 8, padding: "8px 14px", borderBottom: "1px solid var(--border-0)" },
  rulerRow: { display: "flex", height: 32, borderBottom: "1px solid var(--border-0)", background: "var(--bg-1)" },
  laneLabel: { width: 200, flex: "0 0 200px", padding: "8px 12px", borderRight: "1px solid var(--border-0)", display: "flex", alignItems: "center", gap: 8, background: "var(--bg-1)" },
  laneRow: { display: "flex", borderBottom: "1px solid var(--border-0)", height: 76, flex: "0 0 76px" },
  laneCanvas: { flex: 1, position: "relative", overflow: "hidden", background: "var(--bg-0)" },
  detail: { width: 280, flex: "0 0 280px", borderLeft: "1px solid var(--border-0)", padding: 14, background: "var(--bg-1)", overflow: "auto" },
};

Object.assign(window, { TimelineView });
